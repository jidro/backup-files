// ==UserScript==
// @name         书签地球-免登录链接自动跳转
// @namespace    https://blog.52ipc.top
// @version      0.3
// @description  书签地球免登录链接跳转,点击链接直接跳转无需登录
// @author       blog.52ipc.top
// @match        *://show.bookmarkearth.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// @license      Mozilla  
// ==/UserScript==

(function() {
        var bookMarkLink = document.getElementsByClassName("link");
        window.open(bookMarkLink[0].innerText);
        window.close();
})();