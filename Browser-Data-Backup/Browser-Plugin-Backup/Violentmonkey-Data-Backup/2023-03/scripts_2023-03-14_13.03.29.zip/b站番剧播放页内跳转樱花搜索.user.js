// ==UserScript==
// @name         b站番剧播放页内跳转樱花搜索
// @namespace    http://tampermonkey.net/
// @version      1.2.0
// @description  打开播放页面发现没会员？点击追番按钮旁边的番剧名跳转至樱花动漫观看
// @author       kakasearch
// @match        https://www.bilibili.com/bangumi/*
// @match        http://www.yhdm.so/search/*
// @icon         http://www.yhdm.so/favicon.ico
// @connect      www.nekostu.top
// @connect      localhost
// @run-at        document-start
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @require https://greasyfork.org/scripts/430421-%E4%B8%AD%E6%96%87%E7%B9%81%E4%BD%93%E7%AE%80%E4%BD%93%E8%BD%AC%E5%8C%96%E5%BA%93/code/%E4%B8%AD%E6%96%87%E7%B9%81%E4%BD%93%E7%AE%80%E4%BD%93%E8%BD%AC%E5%8C%96%E5%BA%93.js?version=957831
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';
    let window = unsafeWindow
    let upload_url = 'http://www.nekostu.top:1760'
    let search_url = "http://www.yinghuacd.com/search/" //换成其他url以跳转其他网站 如age "https://www.agefans.vip/search?query="
    function handle_name(name){
        name = simplized(name) //繁体转简体
        name = name.replace(/（.*）/,'')//去中文括号
        name = name.replace(/第.*季/,'') //去第二季
        name = name.replace(/剧场版/,'') //去剧场版  "剧场版 王室教师海涅"
        name = name.split('/')[name.split('/').length-1] //去/，保留最后部分
        name = name.slice(0,18)//樱花动漫最长支持18个字符，太长会502
        name = name.trim() // //去多余空格  "无限滑板 / SK8 the Infinity"
        name = name.split(' ')[0] //以空格分割，取前面的   伊甸星原 EDENS ZERO
        name = name.split('，')[name.split('，').length-1] //以，分割，取后面的
        name = name.split('-')[0] // 以-分割，取前面的  "催眠麦克风-Division Rap Battle- Rhyme Anima"
        return name
    }
    function change_url(){
        let a = document.querySelector("#media_module > div > a")
        if(a && document.querySelector("a.av-link")){
            a.href=search_url+ handle_name(a.innerText)+"?bv="+document.querySelector("a.av-link").innerText+"&yname="+a.innerText
            a.style="color:#FF44AA;"
            if (! document.querySelector("#media_module > div > a > img")){
                let img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAqCAMAAAD79pkTAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAPZQTFRFAAAA7GyL7GyL4HuQ526K6Wh/7lt67mF87WWD7mF87WWD6GeD7Vt37lt67myH7mF87mF85WyD7GyL5XqW526K6Wh/7WWD7WWD6WB77mF86Wh/526K5oGW5niO6GeD4Iej5WyD5XOS7mF87mF8526K5X+a6WB75nSL5nSL6WB77WWD5XOS6GeD6GeD7XGN5nSL6GeD7myH6GeD6Wh/7WWD6Wh/7myH6GeD6WB77myH6WB7526K6oOo6WB76GeD5XqW6WB77Hqd7WWD5niO5nSL7XGN7myH6Wh/7myH7mF86WB75nSL5nSL7WWD5XOS526K5WyD5XOSmh+dTAAAAFJ0Uk5TAFVmEVV37syI7ndm//8z/91EMxEiiKqZiJlVMxERRBEzIruqRBHMIjP/ZjNVd3dmiN3du7uZRLvud7t3EZmZIt0R7iIRIlVmZmaqRFXdVYhmRHtUuBsAAAIaSURBVHicpZV9X9MwEMcrsLZZLyQ8rBUKTFseHKLOuTJEBYYiPuDT+38zXtKkTdKO4sf7I7mk3yZ3v1xTz/tve7Qk2uWVB8HLPT8QfUj6D6AjAkARXGWU8rUuep0BpZRseBx7YJsd+IBKixOQfa8Df0wt2+rA+/+Gb9v4QnHSdEd0uwxMfE/MDZ+kDvw0QznyffQykya4xEFIKD08MulnHJ8BjOIN79jEc3EO5YvPa/qkioCnHqmjGa0exFQNyUmFbxINANsf1Hg+DOqdXhh5Ggm+5NrzX1Uu0LEZfB0xkNfqVZgYdGhL86bmmfbqLWFqoLtrvbxayDDjBHhxuqPoGREiOqQzgaOz7K3El6jDoh2es8YcfSfx97yBo2gpceYgUNEEbiREzBbuGrnCnaJVeO7i21qaeCSTrdKDYuitKBdEZtiOCqPEoiTOsumH/nhS6kB42U8utgLiE34+cGsY7TLxqw1UexV53nzeRPErSFoUxRPaa4PLmm+1sIVu6GxY1qDnxArk2hpaFVZqaSs/tY4OILHpj06JjHM7a/bJwm+caD+H9m503V6+PBa9JJvf2jh3Yr8VSzBSPb3RnxKRRxa5uTIa9I7GCkel9R1wnOasrDnLvoiiSBSDd1ak3K94xRUL7u1MRgDf0B1egcYXmlRb/TNOy+jv+0EFPgJn6nqTt6PfVjDavt9d/Li+06Ofs9mv33/uwTvtLyCPR618Lt3pAAAAAElFTkSuQmCC"
                a.innerHTML += `<img src='${img}' style="height: 15px;padding-left: 3px;">`
            }
        }
    }
    ///////////////////////////////////////////bili////////////////////////////////////////////////////////
    if(/bilibili/.test(window.location.href)){
        let i = setInterval(change_url,100)
        setTimeout(function(){clearInterval(i)},5000)
        let ci = 0
        let obser = setInterval(
            function(){
                let video= document.querySelector("#bilibili-player video")
                if(video){
                    clearInterval(obser)
                    let observer = new MutationObserver(()=>{change_url()})
                    observer.observe(video, { attributes: true });//检测video变化,防止中途切p失效
                }
            },200
        )
        }




    ///////////////////////////////////////////樱花////////////////////////////////////////////////////////
    if (/yhdm.*bv=/.test(window.location.href) ){
        let items = /search\/(.*)\?bv=(.*)&yname=(.*)/.exec(window.location.href)
        let query_name = items[1]
        let bv = items[2]
        let yname = items[3]
        let run_num =0
        let i = setInterval(function(){
            if(document.querySelector("div.fire.l > div > ul > li") || run_num>=10){
                clearInterval(i)
            }else if( /未找到相关信息/.test(document.querySelector("div.fire.l > div > ul").innerText)){ //出现bug
                clearInterval(i)
                GM_xmlhttpRequest({
                    method: 'GET',
                    //url: 'http://localhost:1760/bili2yh?bv=' + bv + "&name=" + query_name+"&yname="+yname,
                    url: upload_url + "/bili2yh?bv=" + bv + "&name=" + query_name+"&yname="+yname,
                    onload: function(xhr) {
                        console.log(xhr.responseText)
                        if (xhr.status == 200) {
                            let data = JSON.parse(xhr.responseText)
                            if(data.code == 0){
                            console.log("found")
                                let name = data.data
                                window.location.href = search_url+ name
                            }else{
                            console.log("not found")
                            }
                            console.log('上传bug成功')
                        } else {
                            console.log('上传bug失败')
                        }

                    },
                    onerror:function(){console.log('上传bug失败')}
                });
            }
            run_num +=1

        },500)


        }

})();