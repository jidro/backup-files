// ==UserScript==
// @name         书签地球-不关注公众号实现页面跳转
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  无视扫码关注公众号，直接跳转真实的地址。
// @author       Dreamer
// @match        *://show.bookmarkearth.com/view/*
// @grant        none
// @license      MIT
// @foo         http://show.bookmarkearth.com/media/img/logo/favicon.ico
// @require      https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';
    $(function(){
        var url = $('.link').text();
        console.log(url);
        $('.actions button').remove();
        $('.actions').append('<a class="btn btn-default btn-xs jump-target-url" href='+url+' target="_blank">继续访问</a>')
    })
})();