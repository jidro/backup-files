// ==UserScript==
// @name         普法网（宪法小卫士）课后练习、考试自动答题
// @namespace    Ne-21
// @version      1.3.6
// @description  第七届全国学生“学宪法 讲宪法”活动
// @author       Ne-21
// @match        *://static.qspfw.moe.gov.cn/*
// @icon         https://blog.gocos.cn/wp-content/uploads/2021/07/2021-07-2782.ico
// @connect      cx.gocos.cn
// @run-at       document-end
// @grant        unsafeWindow
// @license      MIT
// @require      https://cdn.staticfile.org/jquery/3.6.0/jquery.min.js
// @require      https://cdn.staticfile.org/limonte-sweetalert2/11.0.1/sweetalert2.all.min.js
// ==/UserScript==

var _self = unsafeWindow,
    $ = _self.jQuery || top.jQuery,
    Swal = Swal || window.Swal,
    columnId = getQueryVariable("columnId"),
    answer_list = [],
    exam_list = [],
    time = 5e3, // 答题间隔时间，最好为5秒
    num = {"A": 1,"B": 2, "C": 3, "D": 4};

(function() {
    if (window.location.pathname == '/xf2022/learn_exam.html') {
        Swal.fire('宪法小助手提示','点击确定开始考试','info').then(()=>{
            Swal.fire({
                position: 'top-end',
                title: '脚本将在5秒后开始自动作答！',
                showConfirmButton: false,
                timer: 4000
            })
            getExam();
            let t = setInterval( function() {
                doExam(t)
            },time);
        })
    } else if (window.location.pathname == '/xf2022/learn-practice.html') {
        Swal.fire('宪法小助手提示','点击确定开始练习,脚本会自动收录本练习题目数据','info').then(()=>{
            getAnswer(columnId);
            let t = setInterval( function() {
                doQuestion(t)
            },time);
        })
    } else if (window.location.pathname == '/xf2022/learn_practice_list.html') {
        Swal.fire('宪法小助手提示','使用说明：<br />1.做综合评价之前请先把练习做完以收集题目数据。<br />2.脚本运行故障如综合测评无操作等，请使用Edge浏览器+ScriptCat。<br />3.问题联系邮箱nawlgzs@gmail.com')
    } else if (window.location.pathname == '/xf2022/evaluation.html') {
        Swal.fire({
            html:`<h5>开发及服务器维护不易，请作者喝一杯奶茶吧~</h5><br/><img src='data:img/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAGQCAAAAACl1GkQAAAABGdBTUEAALGPC/xhBQAAACBjSFJN
AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAJcEhZ
cwAAFxEAABcRAcom8z8AAF/gSURBVHja7b17oM9Vvv//WMit2CqXXJJrQoUmdKEJJTRUooYKzcQp
NaU5o2YyJ86kmTgTE510MZOKUrmG3GPaIiKykbuN2O7bdW/25fP6/fFe7897va+fz8acs3/f83n+
wV7rvdZ6Pz+v9b6std7r9XwpIYXihBL/2wRScCPVIcUMqQ4pZkh1SDFDqkOKGVIdUsyQ6pBihlSH
FDOkOqSYIdUhxQypDilmSHVIMUOqQ4oZUh1SzFAqiTI5369enZF5qnS1625q2az+/zbj/3+h6LaT
BNgxvLS7wv0L80ILH/r3XsuN5MkhD8wTEfnml787LCK5f+o0OSYi6/s9s0dE8l+/c1yhiOx4sv9m
EYm9f9dfzJan/+LlMyJy7MWeS0REvurxYrZxdPWjg7JE5Nyf73o/JiI/PvHkjvDfYNOae/+Qk35a
Hti0koOH1gXYTiNBh8yrF9SJLx8Jaw1Y6SSvA2aLfAsoEekKjBfZCpAt8iwwVOQAwB6RvwL9nLqf
AG1EpDKwROQroKpzdD3AaZE+wCiRPQAHw3+kRWsW0NhPywNNK8n+cNO6ENsl0yFLyofdV388GfrL
B7qT7USe1HciQGXL8iywkoh8DvCPeNJGY6PSQyI93EeHACyPVxoPMDWyQwaK/Nxo0qAVUDjhc8NG
j9DCRbadRsRL/cgv2uWEHRtecW7YobruZEN3TmOoBVDVSqbBVQA1oKG7XiPj7/rgefzWBqgcL1kD
oBpRqOs+Q0MfURNpJImwt8J52g4iroVFCbgMOOuvMxganHaSo6DcQZFT9eFFEZkMbBfJbwuPi8gS
YJVIrAd0KbSeQnOcunuAv4vIf0K1bJHsqvCKczS3OTwjIrOBDJHCzvBQLPSnaFoHy8Lf/LS8l7ZF
Kzl4aF2I7TRU2CaHNwYlujpqrama7IX0fwwXYruQDpEX/yuJE2de87/904sjLsx2IR3ygtlmlZZ1
bmjesFLu7h82bP1hZ8w4srfW//avL4a4QNsFPsj+5hxXdf4w+1j8QM7y0a2MsXXJE4HVj98Ik/zZ
86DKPpHCPu5x5e9gYExkR2lId3IP14XpIvIutDkjcuZ2eC/0wRt7CgYb6Zehb/hcYiI0OyFy9h4Y
46e1Gtjk0LLxGvTIT4bWBdousEOMd1L1F7e75zIF+8c1Lxk/3CHwTfpMcE8D3C0yDWBDPPdbgMUi
N7gr/VInAYaJvBx68YiILARzApQBltmCAfCsyGjjDAYtgKscWhrbAT5IgtaF2i5o2Hv4rngXd5j4
Sv1LXAdLVn/y88fL2anFbwXddd+F38/LYTPA7njOToBtkOEu+K3x91pYSxS2xRsi3vjmyBrfwfpw
WgccWhr7ADYmpnXBtgu66u61j5V5NHg94vh/O2OEoBITgUr+7FbASJG1AFnx3EyALSIvAV2cwuOA
BvpSnCkyI4Srhc0AmfFkFsC60NIVgUn6tvLT6gU849DSOAqwIjGtC7ZdwI9cYpcv/XTYakTs8/gs
7NaAGy82odHDWf7s7D61RxeIyJJbO2YY2WvatV0hInnDqw8w5rCF4+o9clhE9nS//lMRkclNu+8N
NbEsb9t+jZHM6Hjr0vDCWQ81+iAmIjOad9vpp3VmUJUhZx1a8T7v0nJ+YloXbjt/hxTYc3716IHQ
3xT7oKLdarqkYOMi2M7fIfPs0h122VlHZv3mzmolL2/9xMf77D7NGWwv3DcMnyH/n8NFsJ2vQ2L2
GmX1RTrnzNyeNa0WSlTpPClb5+6+wz55hoTh3Pjfrw7I3vPq37IDsuc+83FA3+a+M2S9kcx//3fm
An9s0jPzRET2j/jrYRGRGU99FtDGmbeGbg6g9ePLb505X9PbtNYPeSf3otrO1yE77Jvu9/lWxtE/
1zTGAJWe2akLzqqgs54IZd0u8K78CcBvifdxzyU0bgSM18ODwDwn+TtggsghgOMibwDD/W3UADb6
aG0Eap1vh2haq4HmF9V2vg4ZrovW3a7bHFwBE6Ue2GYdONHLzgpdKcM9cNIYC7DEl10yeBwF0Med
vNmdvETkQ4AvQpfOAX7rozUocuCWAJrWo642LobtvPMQ+ZP+45fWWkvuO2+fchUo+GLEUQAqPmC/
mzYQgSq+nEoAl/myrwpvo7I76VmXq66XyytAyfA2rvDRuoILRGUPs4tjO08HHbEJz7bSc2v6alR8
x3pMZ92tM/4Udhm9BOz25eZUhTv8T/rlBK63DMSctMgIzNmBTARWiOTVhxYF1tRipr+N3sBRH62j
wCPne4doWllYnwEunu28HZKuC95rrcEc6RlwZdym35Av6HTjUNrblgUt2OSv2RBUOGvx7qDsrStO
m8kdXx8zk7sXHxARKVy7PiYism9R4GRl88pcM6lp5azcLOcNTev08q0X13beDhmtC/7GSs6uEdDo
Za9bBxeG3GX/V3FRbOd9h6zW/zex/pt/MKDR0/N1b5OCiYtiO2+H2Et8za3/1hcGVVpp/ef/jD9F
qaf9NQoHKjU1/HeMUWokkNVMlc0ILZTXV6k5F2iw3B5KBXxc/U6ptseK2tZspfrlX1Tb2fDcMfbb
X29WqRZZydcGwNu+W/mtgPM4WA3wtTU7KBta6s+RbSSHwcFtAPQoalsAr11U24U8suxxWiXddlGv
HEhPIsfEBoC1sAQ4G1rqq6IT8WF++KGpybcSzunCbYf/kWV/0sq1/qtYlLYsdPflPBhZvhVAW+gP
tAgt9ch5/To3ngjOrgUMPp/2vJwu3Hbgu2Vq62w9ML0lsE6ZsNtuTT31tn+GERtHvTUSinmV02aK
yOn+3BWxRDqKRuGLZsmhYDjXb/Fn723F87lFbSujEaO9v/TCbGfne9IddTk9Rft14Ea62xI0+n8U
F8V23ko36f/1iOGuKwPaLNvB+n/j+d2T/8/iotjO2yEt9f87rAdh258F1Gl4n/X/rFBqO99dIIAs
eHcn4Vg2aiVAzpTPzCWfvC8mHgHYPG5xhFLR4Y++yAf45xvfA5z6dEoOwMpR3wCcnf7J8XBaHsiS
NzMAsj+eftag5YFNKwIXx3aeO2a7zm7wjZWedLmvRunh1l6KnId0xqPe224t0FusLRrhn7bfAiaK
5AA4324L6gJZIt8AT4fW3Q/ULxB5DZghchIgR+QjYJzIuQq4Fq88tDz4A7DIWolKy4vT8sCmFYWL
Yjtvh+TZVUdb6ePPeF16VFe9m2Dx1TpnmrfR+3VPA3QP5a+vhy8BPovnfg8wUuT2gKvFwQiAtVYb
adauYebGm0yHoF1c9wc3CdBI5B2AZWFL+DatKFwU23kfWZfcr//4JAuAtN92da9pq58PsxaX8+bt
1Vm3e6+DS0L+DkTJ+D9OslSiemalS3xtlHAnk6DibyPohAnczS6K7XzXgr3qVfotnbHt1+ZXltJd
7QHseruT6/sulY3AABHpj7UJMBgTgKki58pifkAsbAYctibwL4TWPQy0KBQZA8wXOQOUPycyBfhA
JL8W4F9ntml5MBxIFzkO1C6I0/LAphWJi2E7X4fk2tVb2OvKR9651f6cVPaG4Zl69H26r13wUz+z
fZ9ZO2iWf7Yvgv+69zNERAoWzDtn5MaWfHFKRCTzk5URdU9+sSQmIrLmgx9FRM7NXVAgIpLx/joR
kcLFc3ICKtm0PPhu4nYRkZw5iwsNWh7YtKJwMWznf1q+bN9fT9jXWMHmUR3TgDK3/cfq+N7IjyrZ
jZ73RoH/93ARbOfvkEN24fJvRmzwWRB3oHtNUrBxEWwXMOr4o1286uehrS63J0HmiNWHtZczOF8k
9hplvxaRrXXpa3z923cbnQKeygtLMkZEcp+imrFTpPBlKpiPsDcouTD8xLPcg6yvyzLC+Cmalhfv
wuyi0rr4tgvokJPx8tU+DF7jiS1w2pwo4QAYYc0OEJEKuFxCbwY6+er8BDDTmh0Y5DxL+DMAQt9P
28DcuS4enpqWB4sAtheR1sW3XVDjX8ZrVBy8J+D4mY8ch9+boly6AZqK9NQ/wjOqCxzkyQKAp0Wu
cB/9uTv5FMCisPNOBfgP95ke9tHy4I8A04pI6+LbLrDxAc5I7Y7Z3tsqd30fw0n1pwhythPFeKND
HneONgba+ursAZgi8pz7l49yJz8DCN18vQVgvpvHP3y0PJgHsLWItC6+7QIbP2t4W1Xo9Zm5YnDm
q8GmK9ZiicJyGHBOpPAlyzwZadxvzA4yG9N6v7/SDHg1JnKmNyWMNfv8QWBsaI8ND9zvY2NyfLZs
23qIcTVqWl6MskahRaJ18W0X7GN4yPz8mHbzTR1vs74Bb5y1dsVe49D4X5OCBxdouxCnz911kjn3
6EH/27++OOLCbBei5HDN3ohdmTbG+9tcs9i1efKHua4l601f/GQmt07bYSYzp7u80LLmuLZZZi9w
uY/lLnH5zRUsW256uMrKr/PMw/9jtC7Edjb3EJzokKjNgEFOV1waMM8B25zk67ikaT7BGvhrfAWM
d5Lrcfnq7sElTXMMaOuM9HMrQC1nalF4HWDMeP7HaF2I7TTCRwyxNyObvClojACu8Qu4PkCAuXff
O76s6k52cCc9jr2jwfTknQbmS/JbgA/+F2hdiO00wsVn1NM7bg1vc9KamiFHPKIrZ9zJk4TBc+R0
ZDO5AOfiybPxf4gfyHXX+B+hdaG2gwQbFNIbBlcaEbJe0hjXw6AbLh2X53DJy7yO62EwGddlvATX
pGU9cIeT3ANUc55R2WA+o3LB9Yz6H6N1IbbTUBHfrQE2vDHem1X/z78I2wiZN+3Q/bWdZOGMXfc2
Nvp+9vqOLY3S85ff2c5ILlvcsrNykj/MbdzVuH+3z6r1gPGBaP/0Sg+WdZLHppV80NgHdWZq7gOG
F8n/HK0LsJ1Gog4B1nz5yY/xxKPdb09pACWPotsuiQ5J4X8S/xKZ2NiYinfu9mcf7FxqWH5opbOD
VU9jE3rhiHJ37we2tblyvHHR7Lur3MhCYEqtn60LJ7DyxrpzgPyhpboccnJtWpl3VhxrNGnTml23
2SqjjfQm1ybSIQN578o22xOWKhLkX4B3CZSXbESUvOSzWKqXGn/FkpcEmOxkVwZGWbMDDoU1tQdg
pfUBz3BRsmmB63OJpvUtmOuVWyHK41vjk4tuwn9Jh9wUTBPgknAm7ko1dRJcnrwAtbUH7ZKwpmYC
DPc59t5kNOn35P0TwBfx3A8B3kz0Sztd9A75lzyy7gg/1DH0SEt3sr3xt8fdqJ3etVknrKkGADf6
TnZHyN8WrWbxmgBcB9A00S/9FziRXdTu1TjVIXBx/GtoGvqYkT214Dsnmd0KFojIZLjfcOaeD62z
RQr7B3kGxTEKno+JHGzsEi6wac2Eu4yFFU0rNsi9Zj8chiT8pbndAnfdXABSo6xihpQYfzFDqkOK
GRJ1SE5NpQzXrYKWSnWIQbpSaj5IN6WaGF8eBiiVdgL2KaVeTZZBrL1SrQtgjVJqGtBbqauNlcDB
Sim/H4BNa4pS6vuEtDSSozVPKbXMoeXBTqXUm35aY5RSu0Kb1LS80NbyIME75i0AR/BgFsDXImWt
qqsBPnFKA/xFpF8SDcexFGCOSB2r0o8A49xN+kWCbFoA9RLS0kiOFkB5h5YHv9BteGgBdAttsmzw
ibW13Eh0hxwEcLrxKMCx+FL3cYBD7hpZ8BNFwDGAI5BpJU/Ez+pgfyStXUnRoii0chxaHuwJp7Un
tLlw52KyfDkJrpfNAM6WryyAo5Z/xhC9L8xQKKkIrLN2gbdO9g45CpBlyUs+o/13DNfMeoB/i7RN
ayDwdkJaGsnRegkY6dDyYAbWPNVDqxNRu2A0LS+0tdxIOOzd9PcrnjKEjHa/U+rJGiAfz7qnbwk4
NC6nvzOZ4sS4rF81A5Z9dN1TZUkS+8cVPlkbZNr0tk+UhGNvZT9hLI6feSuzX0t/JU2rcHx69wdU
Ilo2kqIVm7CgWy8Vp+XF4o+bPVnaRyvv7fW9wr/b2rQ8sK3lQmoeUsyQGvYWM/g7ZPad/Q8BJ35z
yyTj7sl9odlYQ0wlf0STYf5xJfsev3sRwJQ2Tx0Djj7VJkizYmXX3tuBc0ObjvSPK8l8rHOEFodN
K71zH3OBf90DD20yktt6dV0FxN772fOnw9tadPevzPeypmVjU8/u64DCMc1ezE1IywPbWh5aScH7
UpmLpQFzIzDByX4Ql7zk74D+/tcUQLoVxaiWWOKTU3yFNgIcFnmCoAHtcYAgLVMLmtZqgOPx3B1g
boY/BLDR0sTsENrU1+6fb9PS+Algp8grQI+EtDzQ1vLQSgq+Drlf0wRo5DZ1wp3rAjDA8aCFoH3L
IwDmhbWRDvCHcL4WrRcBlsVz3wHTk/dLgJGW/0P4MPIJ91GblsZkgPfcjr3htAJY4qOVFHyPLHPF
ubn70PXOnxECktfBDUbyBl+BeqCjRvnkLdFamCEbNhxaDeNFAb0Qf3U8WROgviOtEEo0jJbd2jXQ
OGlaHlzvo5UcvD10srEVqGkSVDKG4QtxzQ7WEjQ7kOHQOlfkaC1417pwa/v99wvug+fFUr0MkBV4
Ce4Kj/anaeV1cI3sY71hgOGyNAjuLxDJVFGzg5xW8Kqflt1kf3gkZs14Fiek5YG2lpdWMkgNe4sZ
UsPeYoZUhxQz+DrkVGOlRgOTlEo74GQvUkptcZLrlFIrgEFK3efXejxaU6l3gXeUujpcXnK5UuoH
kP5KPSKwRSm1GHhJqQ7GZqFRSjUxfAk0rbz2Sg1xaEkvpQaIQ0sjUyn1RUJaM5RSu6Gwm1LP+2nZ
iKblgYeWBzat4Uq1zvUd9b5UhuhMgIecbHA5Sl5ulVoHQTMNM9bqQAkDQGVL9ocF8VirW8HnEPhH
d/Ih7ba4LU5rPsDyOC0bHk/REFoA7XQI2B98tDQS0Ar4aQYtD8wQsKO8B313iDmz/MF9yBDdyrb+
2w/g/zBjqr1GCsNzRC+K7wa95fIgmLGfgPghg9b2eFHYqJfuf4rTsvF90rTW6qBTWT5aJE3LA4OW
ByatLb6j3h6aB5QTkWa4XCx64BojDgYGWBowAfIyU4DaIlKLqJDB/YEXnCnxcKCnnhIbbpVlcDnU
alqrAU7EadlTYk3LxhjgroS02gNjnZm6h5ZGAloeeGh5YNOCgGge/ons7HYDDorIiWdvnWQMoXNe
bD62wEnmj2g67JyIbOt9X1Dc2CltBx4VkaMD7wjvDzk39PqR+SKy6aEH14lIwZjmv88Vkcw+XUyW
Bwe0N7/b2bTSu/TdbdBa1/3hTQYtjdh7N//WFI4PpnX6+ZbjYyKystsj2/20bETT8sBDywOb1r5f
dfR7UqXmIcUMqWFvMUPJYRelmdmv7L/J37e5YyZUCojBu+0vy5tcGtrU0ddn1K4CLHpl900l4fTf
JlUxPMDOvfnupfWATX/+7oZyUPjOaBqr0LY0rROjPqtxFZA+fFuLS0JpebBv5IKGlUCmvnKkRfhl
u/LVTc1KO7Q8yHxt6XUV/NnB1tKQi4GPCJSXvJkgf9NdEKEhlAOwWWQ60FlE6uIaOd4DzNB7U3Is
zZNxYU3FaVUg/qm/VSgtD44AZFn7W8LFOL/BUoXTtDzYD0FinCHWsnBxOqRqcNcCdPTljoYITY5v
AYZZHz7swbrfZfZlgJWhnwE8tACeFbnLSHaUBJgG8EGiM5ihcZv7jr4PQTF5q0Y1eXHeIXXDD/lX
n6tBXLDejzSAq8DcX+AJdF1br4ZrHZd6YU25aFV3U0m4KH4lQOWILfY+Zv4dEVXiDSVrLS7SI2sj
rkmLjeEEDcPPNYH7wxele0PtM9YY/k0RGQwlDD2xMcBOkTO1rPhRU3DNDkJo/RtUOiGyD2suFUzL
g8IOcEuBNeMJH7sfVvCiQ8uD/FZwl1+DKcRaFlLD3mKG1LC3mCHVIcUMvg45202pT4H5SrU+7mR/
p9TVP4G85N5APkqpQQIHr1PK2CRzur1SM4EZSnU4A/m9lPoA+FqpJodAnrMW+D3YW1Op7wiDh1as
v1JvO7QSYIJSvQt8tGxoWjYylErbDgy3FvhtWuOUGhCD7JZKLfCfwUNLw2utYFoeeF8qf9KZ4At5
2kp7v37nej3xhc/3cZDRxvM61qrE/TdnQtCK5M1BbMJofQiwK04rAQDe9NEyjxpupRWA+iKrAJbE
ae0EmOiNtepqw6Cl4bFWCC03fHfIcuPvpe5Dq/QKvLNkvB1gPSx0FzR3lC0D0/t7kV7U9zt3ryYK
HlrfQ3xxfBXJ4DsfLROGR/opYIf+kZvitDIBvveZxISHFj5rhdDywNtDk3VmFVw+kG2A5y2xFbbH
c/cCrBIZiuvz1XtACX0JjBeZrZtsDAwTWQlBApDPEarj4qe1BOBQnFYSd8gcHy0bmpaNbsDjWmo2
I07rEMBSS5qmmv8MHloaHmuF0PJkejNi4yu33S4i++6+dKSx3n60h3ohV0QWNbreXIVe2bzeHBHJ
G3rJvYZ/bWxsWvvdIpLZrtLYmIhMrH7rJhE52KX0sDwRmV2vecCafe5gevqXGcJoTbm65TqDVjQ2
3Vp9UgAtDZuWxol+PHNaRNKbNlpk0Fp3c+2pIlIwonzHgDmMh5YNj7WCabmRmocUM6SGvcUM/uX3
bRP2XufvJpnzcanawNGJ6+qXBRa/nx/gEXPus6+qVwI2vZ/VKKCNWZ+VM7XU5n3gWtZJ/0dOQ2Ml
fd0/jjRSkD9lftUr/LT2fbi14SUOreQQTevgR5salA6tmzs5vaahyGXTSg7aWqc/XnHNpcDK909c
qxxreeh4sJ6gDdLyMjDZEp/ktKXjMspf6jpgm7Vie5//6LO45CU90m2f4JKm+QpLXvJ2IMNHaw9Q
NT9OKzlE0zoAqLNhdfMqA4Z2uKaVHLS1bKG7WcAgx1pu+DqkX1AvxX1TJwHMidz9PthxVQ04Ws+d
NEp5XFVb6STAr3y0XgVYE6eVHKJpvQXwdVjd1eBymdW0koP+pUsBxsX9jYMdjH138GWEIg3KAUS7
6V0KFcKPeuKRGo+otPCCl/loXQpQJrBiOKJplTea9KMM+EI8R5gqEGV1G+ZP83859fbQHlwqjzbe
A5aK5KZB7XxrahEgutINOGiN4QNmB6NwiU9OxjUMXwL83Umux5od9AX2+mhlA3fE4rSSQzStUwqu
D431EGsDZDtpTSs5aGsVNoESp62J2GjHWm74h73Hv6vqcw0Ftmxufg1QsLJkqxLAjvXXB3lLfH+8
1WXAkTU1bgg4+uP2m8yX+rYNzcyPS7vXXdfISB74/pqmAOsOt6zkp5W78rKbDVrJIZpW3soyLcM/
z7P6dOtyRlLTSg7aWvLdudalgZ/WNmhsWMuF1DykmCE1DylmCO2QNUr1zgEZbi1Z2xhnraTvb6ma
7AYmKzUKONFNpRm7Zc/1tzahL1dqQF7YCci8TrXKAiZYS9ZH2qtaW4EZSr1q3LZLlBpUAAXPKbXU
oeVFUrRsaFqxlwIlYTy0bGhaOb2UWpPQqltrqg5HE9Kap9SQmK9u2IsIYJAOZeOMv9MB1oncBjTW
oWzmifTBpXr5sm4YolQvGwFtLO84vrEU86toAcvP3TxGW5MWHFoeJEfLbHKoE/gnmpaGTevZKJvF
cSXQLSEtcA1jLEQ+sibBEoCt8ZxVAGut1fAf9R7y5fAhYFzVU4w2poa2vgVYBmt1u7OAw7AZfIvc
s9zRlSf5mkqOlompMD/4iIeWhk1rIsngKPBFUrR8H7siO2QAdIK4Jyo6dOvNVnZrLRx5JwzEtbGn
r9FGn9DWWwJd4GaA26AX0ACaANzjLvkQPOym5UFytEz0gfuSoqVh03oyqQ6pBzySFK1uvrphd92m
q3jmrIiMpbS5y2+itSnmcCfa7rdG2ONF5HQ/Ghjr/vmDqbxORNZV5oX8sBPI/jZ0OSIiU2CSiBzv
QYvdIrLoEsYapVamMaxQpHAoaasMWh4kRcuGphUbwaUBi+MeWjY0rbNPUz08vK+N3c3peTwhrfTy
jPRth0oNe4sZUsPeYoakd7+vWVimCpC3YFedEkDGHHVVQKl/rr3KnM4uX3F5hYQtFyzaek1J4Mc5
hTWM7Mwvc2oFlF6ZXrGSn5YND61tX+aZSwP75p682qCVPe+wOcvPnb+3TvhMXZZm1DBXupatqnwp
cGjuMXP5/9T8/WYbHmvFFv94dcL48gmfhxbeAOZZgcvLnrM8JCf4S7XDtUnzCaLiqWucLQ2csVRv
jJfHaoKkaeR3uPaOalo2PLS+xqWYsxFLMUfT+gmXNM1x4OrQN17hjbjiqT8I7LQ2vPZwcg8BzZ31
MI+18mtiKuYEI9kOAaisXVUXRC6/+11mozEfYGoiD1qzyXY+WmbSqNTYneyhk5rWEPfR8RDkMqux
DlxfgAAGOo69Gn8FWB9Peqz1Dbg8eQNRlHdIPsRA/xOKwshkSPlC8GwZKwiv4TmUn2zBQvffQUdD
f5oE/7TCyDZiAcmE9kjyDhkBzNTykrkiEwnUXm+FS3yyN4HyMm7kAJy05CVHOtnLgWf8pQfiUr3R
tGx4aC3EJVGzFmvLvKaVCdziHD0KVAqVlymoh0sTsxOwxZKmMTbZZQENnL06HmvlVSTIf8eNpIe9
6WvbtgDOzirZ9RJg1fJWAZEBZO6RzuY7duHuu+okbDl/VmHXssD3y1q0NbK3LG3YPqD0V9vaXeun
ZcNDa8M/m95pJHctvuZug9aheZXN6FKnZ5f7RXhISJl98t5KRnpeVseawL4FNcxZbPaXFX9hNOmx
VuGss79I9FUrNQ8pZkjNQ4oZfB0ir6trM4CdN6ohxusyq70acAaYUfHK+cDxXuq+I8CSauU+Bc4+
p1rtBdbUVW/7bzkZp+oGLFkf6aZ6G9Lnp59QHQ4Ay2uV+gDIf0k12wlkNFSjjCZtWhNK1VrhbzKa
VuFw1WQLsKWJetV4t+5tqQadBSaXu2pp0rQ81vIgxFoaCazlwfs6szSuMfyNQH+9+eJHke5Ae+1Q
m27NDmqJNb7za9F8HnQea9JijOF/DTTXItXzLPHJsrpJY2qhac2FIN3paFpvaB4AY5xKNYDBWhMz
M1laHmt5EGwtG5HW8rVmuqpWN8pZ2X8D0zd1GsAwZ/wP1jjGjV8Gs/ZcDzq5COBZtwdtR3ep6joG
7eKwJkNomY69/uC3LwPMSJaWx1rBPDzW8v7wQGv5HlmmYHZX588ywF3QAuB6ayX5ar0u3xJ6GJXa
elvk5wSiJro9C+2BcjoK1K3uxXHPaKurXhf3b52MptXJSHZyV+wJrQCuKwotj7UMBFvLRrS1vD2U
18/anJMOXQzv/vVlaXFAREZYPiaZ9am2VUTGw7CYyNE2lmPKVHimwNuiFDwd6Mi6pQoNjElLVnPK
ZYjIRHghJnKys6UDOxseN2YHmlZssHtxXCOaVk4P665aBD2NLfOr4I6jIrGh1ve75Gh5rOVBiLU0
Iq2VGvYWM6SGvcUM/uX306tzrwwouHtN+SS2Tm7ecWXA+nLu96crA+xad9mlQMHaY1UUsHdV2YoB
bWzKrFISOLaq8AqArVsvN/ek79hQwVzgj6Z1eBWXJybtoaUh6w9UVcCBlSUrGbSirZX3/YkqAWfY
t7J0GiAb91YtYdAKtJb3GbafQLGVj4hYCo2jF0GLNUew5EreAtaJ5FSGNjFLXsavARPrBGVOWvIy
I8SSlzHGt69hRmBKQGstUdI0Njy0NApuhHp51hLtRIdWtLVOloYufpGKhcAMkdjtUCXHoRVoLV+H
DArqJWuIdnXC3wbwii/X9KC9WbuqfhcWiXUjwJuOYy9EucxG0woJARtA2qCl8RXAF/EQsDataGuN
haAvQDoE7CqszjVDwPqs5XuHHA2/tQ+SDLJ9OaZS7CEdOkpHkfAvnZ8BOO4OIeWRmj2cLK3kCAfQ
wnLG5SQccNOKtlZ2vKgLelngNMAJNy2/tbw9tBpo4b+MBhMhmBJHLYIukI1Y4pP9galaXvKMpQEz
1lf4XBlgpyXG+ZBYqpfGJ8IeuMQno2lNwaWJGQIPLY3jAIdFJgAvOLSirbUDKHfOV2oM8Kr1AZF9
Dq1Aa/mHvRs+q/2Y301CPl1xb3hgYRs5Hx7sda0/e8vkqx4rD7FPvu/2c2DvpPJ9KoFMXXpPV3/h
Ux8e710XWDH9+kdKwrmP9jxkhGUo+HjjA7ckTWvprJt6JRxHemjZOPJR4aNXAfO/vPVh5dCKttau
jy9/LGAXwRcL2nVXcPzDnEdrObQCrZWahxQzpOYhxQyhHXKkV923Y8C8n3UOEIc4+9KVg3KAjLtu
Weo/KhMaPnTAn5392NWjCoElre/OAHKeu3LIOX+pzZ1/FrLr1qSlcar/Va/mA8vbtDMX+D20dnZt
NjOA1oxmXXcmpJU/vNqAUw6t2Li6vf3hJuPQ1ioSLa/xQlAXGKd3SvinFk8BvbXKo/+r+UdAmr/J
m4ERel95lrUI7J/xHIWoqYWmZeMe4CWtiZkZz/XSAljko7VQ//xoWn8AOju03sJSvQyGba0i0XIj
0h2hnsi/Q5Bvqu7L2RAQzlVaB/c0QHntQRvqybsUAjdkuWl5eLwFZvBbLy2AX/lo9dPJaFo6adOq
E3URx61VJFpuRL5DbtVxp2r6jlQDSsA1YO6Nt9EyvMk2urzeMljdV6AWuKJdBdMy0RyuBVMMM4hW
Mx+t5knRutFNy3NuD0xrJU3Lg7DOng4NDovk93BtzrGxEWt2MBQe93uuHm8OH/srzYdq+0QK+1n+
tasJ3Nc4Ah7yL+F7aNlIh3I7RWJPwwtGKQ+tsdDlnI/Wuc7W3Dua1o6y1nq7pnW4fpBArw3bWkWi
5UZq2FvMkBr2FjOkOqSY4eJ2yGCl6htra6OUKnsITtdT6oWEdTOUUnNCj2ZXUepPoUdjnZTq6X/4
blOWcub5QHoo1Tnmo7VXKfV3P633lFJ7i0rLYy37xBcT4BoCAAzQQU0T1m0QWerFyKNfgutTt8bt
F/AD0wHm+mjd707atAC6F5WWx1oWLv4jK9Od3O7LCcH2yKM7I49mQdBie3SQqGgc0O16aHlWLUxa
W31tJEHLb5vzvICCAS55mcbAHEtspUTCuq8TqHqjsYRA8UmNPRCg4yLvAfef5085CLDXR2syLqlO
m1YbgsR4EtDyWMvCRQroovEMdd9t7ST7lKzyt05Q857cztPLJ6p7S92c/n8O3X1e587cbp+E6kKl
9cpr/anfAa5F45y+o0qd30+5tG/+TR/X9dG6vkVOr7ecD+E2rV+WThvZvai0PNaykJqHFDOkhr3F
DP4OWdLz98eBnKHdzLXhvL/cPcG4mWLj7hxdAOz9za/Mzd+Hf9d7BcC8B/54Cjj1x+7mSvrZVzp/
KkDG47/xDxGRCXe/Fu6dFkLLxub+T+00aNlNTu78ytnwJpf3Ghywkl4wqt3bMWDnUwO2GLSynu+T
WHSGNY89f8Cw1vnQ8r5UvgKqijU2M+Ql++DyeXwZGKQ1MQ0dR4CVlspjY7FUHg3Vy67AeB3FNNv3
qvsrluplMEJoed6empaNd4FuoU1+S6A0zbPAUEsTkz1xWqcgCdXL9QCn49Y6H1q+DjFdVQ31cE/n
6eR8CPJNNYO9+l1m/wpmlNmQMyRHS2M8wFRfG1dENvlk8FHdxucA/3B70P5Hog4ZArA8Xul8aPke
WfWNvxu5DxlJ/SG/CvgiRNUFU/zPIwTYWJev6rtVgxQDk6IF1ACo5pO5bBzVYlQoqDQd5apGnFZl
CIoy5UHteFFodJ60vD2UXdXavfUeLpXH2bju2JVY4pP94A7D2X4wNDgtcrAs/E1ERkE5Yxg+Gdgu
kt82cMKxnsCN5NG0NAo7w0Mxh5bGNgKlOjVO1bfiR3mwBFglEusBXQodWk9Di1BVXxu5zS3XYW2t
86GVGvYWM6SGvcUMqQ4pZgjtkOlK1T8CBT2UGpl0a2OU6hyuejlfqar7IdZXqWHAGqWUsc62s4xS
y4ARSvUsSHQiDy0ZaC3wb1JKfQ8MVapfLFEb5zopNdahFYIi0bKRrlTZXf5sTWtfFSuOVbC1wl4u
AL21m+mORC8zs9IbkUfv1i6ZG6zkVc7RGyw22yGJXcQeWgsBVloumUokA4JCnnowWv98TSsERaJl
/lJ/JFabVgfjxD5rRT6yVuowSvuSvTIA1kceXa71JHWgJmPfmp7x7wN91ih4aG0D2GltmRfd+Oai
EF0eWqpItEys8+XYtL6JtFZYJ9cD3rY0YDhWlCsjPA5zK2CksyOtFy55mZeALnpH2opEJ/LQ2gyQ
aUnTPKKdyhOq3tgb5TStEBSJlo1OuFRvNGxaI4DWUtSNcod71387JiLzbu6yJVkesrNb85nhR7P7
1B5dICJLbu2YISJnBlUZYozs84ZXH3BSRDZ3aTlfEsJDa3nb9mtE5OxLlZ8/IyIZHW9NQqJ/RvNu
Ow1awSgaLY2TA6q/GiAspGkVjKrdNzvMWql5SDFDathbzBD6xbDgw0kVAoKOZ4379trywMwxOU0U
ZL+zpE4asGTM4RsU5IyfU71ywnPu/e/vrzM+/h1+e1n9y4B5b5y43i9CefYf06tUAzLGbm9ayqG1
882MxmVAPnm3ZINwWhoeWnkTPr+8BrB57Oaml0Bs4oSydfwsbVrRSI6WB5HWCnsMPohLXlLjEMBx
S8dluOOk9TmWvGQNYGOiB2yI79j7BG6yvhFYY23wbO7Q2oElL/k7YEIoLRseWu2AdGs7bC2xNDH9
ijk2rWgkR8uDSGtFzkNu9uV+CPBFfEH5K4A3466qAvDbRD9iLMCSeHImwMS4q2oQjz5ODFpN609g
evKG0DLb+K072cUdGtfvyWvTikZytDyItFbkO8S/Rp4GUAH0V//LACpZm+FtJAwmVyleE90aVNTr
3cGoHF/TtmldDvH4TdVDaZnw0KrizvGf3KYVjeRoeRBtrbC+HwH4x7t59aFFgTWGnykSawvVcq2p
xdtiyUsmUnmUnKpW/CiNgubQIM+aWgToyQwEsqwx/DMOrZNl4d6YJS+5IpSWDQ+tl4Dd1tTiEREZ
R9CkxaYVjeRoeRBprfBh78591wfIUsTWl7xeAft/bFQLkE3nbiwFHN5Ypw7AlhM3RsdwAyhYX6ap
eUlsiN1QAjiwqUHQF6BtR2+4FDizvnJDg1be+ksbA+zZ3rRaOC0bHlrbD95QEcjNSGsEkLm7SYAe
hk0rGsnR8iDKWql5SDFDah5SzODrkLy+1m7vdKU6n3Ky15dRzQ8AI6wl6xBMUerpQsjtodSi0EIy
VKnxwNbKqv4e/+GJSr0gcKqTteztoWW3MVipSaFn4D2lhgkcvV2p70JpFQ5UKiD+j4dWVjNVNsOh
FWKtEARby6YVYh4P/qwzwSVLURpor30f10gYAN62BC/Cd3vMAthsDcP9a9SZAJ9YswOjjT+7k5PA
paHtxo8AcyzxSfu3+Gm9FczSQ6sdUNahFWKtYIRYq3tUJd8d8pXxtxH4Kc86tA50LKVQpIdGd9JY
DbAZ9hO0Rr0dYIU76JSHllUgYr/8j/o00yJppQdX9tBaApx1aEVYy48Qa02LquPrkEf0/2WAZ5zs
ZsAArdnYKpJFd3gissBdAM0tecmevqNNAe6F36Aj77ppafwiXjQILQA6wGCcrTt+Wg8GV/bQ6m+1
Z9MKsVYwQqxl0vLDe8vERtEoQ0R2NmeIMQzPas+A0yIyI61yxCr0mnrq7ZhIwXCuj1izn1y++lIR
OdKNRwKiaSy/uvQHIpL3Es0N9R2blo0Jl9SO+DqxpPqln4pI7iBa7w2lFRtHvYCnr4fW6f7cdcCh
FWKtEARby6YViNSwt5ghNewtZvAvv++dcrC+Mbs8PG13vZLAP2eWrg6cmrG5jiHceHbWuquNyWbB
lyuuugzY+fnRekYbWVP31SsBsnROuWpA9vTtdUsBy6aUqAXkzNxQ25CcypvzXY3ywObPT9ZVEJuX
XjktnJbGhdCyYdPSsGmt+TwvIh51kWglBe8z7Eegs5PcD9QvsMQnZ+gQJTnxo+cq4FqOuRnItBZr
eju5u4BWYum4LLI0MdPyrGHnRCegi0ZBXSDL2t38tFg6LptDaWlcEC373aFpadi0pmOJcQajSLSS
gq9DPOP/EQBrraF8mrU9l7nxo+kA7xmtAX+IdFVtJPIOwLL4WvmXAJ/FC38PMNLtqjoglJbGBdHS
sGlp2LQqBF21iawVTCsp+N4hHpe8kvF/4BJ3Ev0GKulr4JLwJv1tBCU9bZSKpMVFoBXeZPQTp0i0
koO3h3bgiqx2GGhRaOk4zre+xZV3BFPyawEnnNLtgX3Wtzhjlr8PuEss1ct061tc7QJLXnKqyLmy
mB8QC5sBh61vcS+I5RiyM5SWxgXR0rBpadi05hEkD5vAWsG0koJ/2Hs4vdrtRvLU0go/V8D3G1pd
B+R9VbK90eexpWfbmULT6cfuuBzY/83VhlIl2f+8si3A6i231Adyl5S9swTww9qbrwcKv4q1M7Sr
5Z+n2l0G7F5RrxXANwfbVgmnpXFBtDRsWho2rc2rrr8p/HouEq1kkJqHFDOk5iHFDL4OiQ1VFVeF
l58YuGRtI72cGmnccuuuUC8UgIxQ5dKBbfVUP0NsZf/tqnOEnqTGygpqmLGRfVM19fQ5YIwqFb7A
z2xrgd+D/MHqynUJaSUHTSs5ax3ppNpmJduy96USsiit8S1EOaOCa6cGwAhLfBKxRpADnaM3A50S
vuTApXoJ8JIVhdLc6OPGNggKiPSa5hFNKzloWslZ6x5cM57ohr0ZP488xesA70fSfNidbCrS0zBE
QCimxL+8vTtZ2VJFDd/WPRWCXGYbGzzCaSVpN4tWctYqyhl8j6z7iEJrcEVoCsA97mRPd87jzp+N
CQrBFASPIPlj0A6CvHE1rgdo48t+KClayaNrstZqQ8S3Ai+8PZQ/yOUx6sW4SLeVeTDEUHlcDgPO
iRS+ZAnoZ6RxvzE7yGxM6/0Jr5gl8Lyxk2aN4pEzIrHhrhi4XkyG0f7cc/0tj4JoWslB00rOWvtb
0TQzyYZTw95ihtSwt5jBv/yenX6yOsCG7yqam783p5erBBQs/6mmArYvLXklIKt2Vi8J7P1nYRWA
NT9W8Ye64FR6dg0jmbfsYM2A7WPJQdPKXXakZmJaIfhh7eXl/bQ8iK3YXaMEkLlERWzo91jrgmhZ
8D7D9mBpwLyMa3z7LrBEJLcC1Mq3do5MFim8Djhtje9GiSUv41dQOwDc5yRPAU386svJQdM6BrSN
JaIVgueAbT5aHuTVhIpnrY3b40NLeax1QbQs+DrkGd1LEBTydBrA4vhA7luAD+KuqgKWOrTfiMZ5
3gdYeZ4dommNhrgnbzitiDZ6+2h5sBBgui/WarS1LoiWBd87xJyznnIfOglnQf8DwDmAXHfBHN9N
6MnJjdc8T5xytxFOKwJngoiaOKebPJmomYtKC3/nr8dSeeyLa0A3FPhUJBvgtKUBM1okF+CgJbby
vFhTr22+Tt+GS1LpIFAioY5LCDStPUC1/ES0QtANWOWj5cEpgGzrI9Ow0FIea10QLQv+Ye/2WbUe
KAWxLzZ3NqT7Ze7qDrcDx6aVfLAi8NXSNh2BM1NzH6gKrFp44y8U5E07dH/AjqPdM6t2NxbYD00r
/+CliS6UENi09k+v9GDZhLSCUThj172N/bQ8ODGtsPsVwLLFLTuHD0E81roQWhZS85BihtQ8pJgh
YYdMqfWzdUZyUcMmAXti84eW6nII2NT6KnNPeuadFccKMLHaLZuAg51LDcsHZtdttgo40Vc9fQZI
b3LtIuDsYNXTiCBZOKLc3YYkjLx3ZZto7WuAMwNVv5PAyhvrzklMKxoeWut+Vivgu4OXlsda54ME
75ivAA65XmIBr+2XsVQvwaV6CfCe3u4uIo2AoXr0t9eatPTTmpgZlvhkG6fuX7FULzU+SYKrJT7Z
TYtPrkxEKxoeWofA9FQNoeWx1vkg0Y8c5CYyFoJ8U20PWoA+7l9+s9tV9RLtquq4zH4I8KZvjbqm
O9kpqQ7RbcwEGJ6IVjQ8tL6CIAdjD61Bwd1WFCR6ZN0EUCeebApBy95msE3Pbu879Cq0U7IZQAPL
xbUBXKfb9USIau9O3pbU7V4PqAQNAG5MRCsaHlp14saIouWx1nkhQYcV9rc8Rm28BK/6Sx1sDOki
MgEeMTQxZ8Jdp0Xye1sT1K+h6SGR2CBrcTxDUWm7iAy3lHP21DKDNUt2K5eWbG63KD1LG9vSKLFB
REbB87FEtBLAQ2scDPCv93hoea11HkgNe4sZUsPeYoZUhxQz+DrksLL0JMcopXZBTk2lDL+tgpZK
dYhBulJqPkg3pZr4dRz3KaVeBYYrpfbDiYpKPQlMsFQvzzVW6j7nSRlrr1RrQ16yt1JX+9f9bFrR
0LQSQNOyMcEtxjlPKbXMobVGKTXNobVTKfXmeVorOXhfKv+uMwG66X0um+NHZwF8LVLWKrUagnxT
+xlt/EoHNdXJW7UHreNLthRMSesfwbXvx0MrGmWTKqVpmclb3cnyDq06VpM2rV+4z1AkayUF3x1i
Cqbu0RGUTsRzjgIci68pHwdLedKNn9x/m3vEMuFwvCa6NXA2zJ2AoLhN4TquJs4mVcpLEV8oqByH
VqablsexvkjWSg7eHloONBBryjNTy0s6Oi5ZAEctR4gh2iPF7y6+EEvlsRWwyHKUqSSW6uUk7fLt
eOgcBciKJ3MgSPXGphUNTSsBNC0bmpaNl4CRDq1xwDMOrRlAl/O0VlLwD3tXfVD3qUsh7+31vToA
m/5+xVOGhtDud0o9WQPk41n39C0Bh8bl9G/g7+VlH133VFnIfXvLo22AH/5RfWBFKHjnu4e6ANvf
vfQpYxV6/7jCJ401+2NvZT8RED9A00pwdWla0bBpadi0NGITFnTrpeK0ZNr0tk+UdGgt/rjZk8aa
fZGslQxS85BihtSwt5jB3yGz7+x/CDjxm1smGXdP7gvNxhYC6x54aJO/ldh7P3v+dMJznX7+5vFG
k+eGNh1pDHcLxzR7MeKDs6ZlI71zn91GUtPKH9FkmDEKt2nte/xuc6v80afamCvpNq2VXXsnXuAv
mrU82Nar66qE1vK+VOYCZcUSn5zgZD8IDLdcuAJ2nb8BdEj4vmoHjHWST+BSvXwF6BFa16alsRpM
eUmb1u+w5CU9tMBa09KogUv1UtPaCEmoXhbJWh4cAtiYwFq+Drlf9xJAI6Oclf0OmC6zNqJdVc02
0nxNhiRDaGm8CKbLrE3L00YF47cMcJ+prY/WCAjSYY1GtLU8+BJgZAJr+R5Z5i7t5u5D1+ulZb+c
b4QTngc/cyeNPYHRkZk8m8cbgqlcadPySEqatK5zH7rBR6se6KhRRUC0tTyoCVA/kbW8PXSysRU/
ahJUcmYHshDYIhLrDQNivm7NVJGb0TVmQAlj0rIcl/jkZoKcbLy0NPI6uEb2Nq21uBTzbVrDobWh
ifkO1DZkBTStgvusrUxFQrS1vBgE9xcksFZq2FvMkBr2FjOkOqSYIVGH5LVXaoiTlF5KDTCecoOU
us8YcA9XqnUuHK2p1LtObm5LazU+ObykVAcjJu4opZqcCi28SCllxJxfp5Ty6/B5ab2j1NXGhqMZ
SqndUNhNqef9dbcopRaHnv9UY6VGJ22tYFoeJHhrjQdz3898gOXx5DpwDekBRvmCmv41ifPEsRXg
H+4m/xhaGlz7cy8PPpOHFrjcbgHa6VirP/jqNo4kP8R9NNpaIbTcSHSHbAdzNTwTzKXr/QCecGRb
4nGbjJzkcRB0TCkHP0bWMCJDZYeX8tDySFOuhZ3g/lKQzLk9qxbR1gqh5UGCC3Y1mDounpn6YYBN
7j5PF5kC1HZyv07iPHEcB5e0ahks18xg9MC1C2YwrhlgCK1awFTnaHuiZurDgZ6h558HlEvWWiG0
PJmJDJTepa/5wWNd94eNDpBtve9bZST3/arjIhGRKW0Hmirzizr+ep8ki8w+XUyWBwe0D4+QKzkv
Nh9r+Ojmj2g6LEB9x0Pr6MA7jP6Q08+3HB8TkZXdHtnur1swpvnvcyUUs9sNMB0Moq0VQsuF1Dyk
mCE17C1m8Hvhrnx1U7PSiarJpOEnmxtuLLNf2X+T0bfpw7e1uARyx0yoZAhI5o97s/S1/rb2jVzQ
sBLI1FeOtCgBR1+fUbsKsOiV3TcZLqua1rk33720HrDpz9/dUM7XVAitE6M+q3GVQysE2/6yvEmR
/YiCaRW+M5rGCjJfW3pdBYfWwf/6st4Vfmt5foMH3wD1Ez7oXwNecpIf4ZKXXIgltnIzro/XvyRo
o/YRgCxrx8bT+uP1Zkt80pCXtGndA8zQm0BykqVVAVjn0ArGLjA/9SeHEFpPAeMsTUyOxmmdBMj0
WcsNX4f8MqiX/NXcpTyuqnfpJAR58nowDeADt6vqMOsLg9HkL40mm2sP2pXJ0gJ41qEVjNEQtboZ
jBBamsf7ANPjyYUAbyRw7PXdObWSulM9gWHqupNXh/xN0NbwKwEqx4+kAVzlE0c3adXWK+9pvrYi
aFUP+mxgohr4AlclRAStelBF/z5N63KAqj5reeDtocMKXkx4ZXyNa3awEZcD9j6s2cFwXMPwCbgm
LRqFHeCWAmsMP1VEekPtM9YY3hCftGmNAXaKnKllxY9Kjta/QaUTDq1gnGsC98ekaAihNQVYI5Lf
Cu4qjNOK3QdNz/ms5UZq2FvMkBr2FjOkOqSYwdchZ7sp9SkwX6nWxyHWX6m3w6uPUmqQ8dCboFTv
AjjdXqmZTm5+L6U+AL5WqskhkOdcS9ZejFNqQAyyWyq1AJis1H3nfLRCsK2iUhv8tDQ8tGxoWjYy
lEoztgPtrRkVMCo5Wh5rHbxOqXTHWh54Xyp/0pkAfbTv466wN9BGcMUWBXjTCWqqMdZosot2yQxd
4tkJMNHtKfqKj1YI6gJpfloag4J+b5yWjQq4JmI3B1cKtlY0bFqdjEo+0WzfHbLc+HspfA+wmxBs
B1jvzvvOF93J1FFdBD/EawYhE+B7WGrkrfDRCsEu4EQwLUKDTmlaNk4BO5zkaqKQHC2PtRa6reWB
t4cm68wqwGiRJRDheb0XwFjuBZhjia2UcHJn6yYbA8NEVgL8FNbkIYCllqJnNd3kpz5aIegL3O+n
peGhZUPTstENeNxJPoclLxOM5Gh5rDUU66uatpYb/hhU4yu33S4i++6+dGSBiEy5uuW68HOsbF7P
bHLTrdUniUhsbFp7cxV6YvVbN4nIwS6lh+WJyOx6zVeFN7nu5tpTRaRgRPmO+0RkW9vK42N+WsE4
PZDHT/hp2T/NQ0vDpqVxoh/PGD66uYPpGR7eNzlaHmvlDb3k3kOOtdxIzUOKGVLD3mIG//K7RmzG
jAoBIc6PTlxXvyyw+P38AEedc599Vb0SsOn9rEYloHDa7MuNOMwy67NyNY3S8z6gLnBi0uq6/pV0
L7ZN2HtdCYfWvg+3NrwEZM7HpWpfIC0bBz/a1CD8u0Pu5PSaRnj1/CnzqwZEjte0LgRhz7s+BKl2
HAM4bak8jvJXug7YZq3Y3ieWvIyxJPssLg2Y14HxjnRbNNZjbZDWtPYAVfOt5dXJF0hL4wCgQoXu
8ioDe5z07QRp4Nu0LgChHQIu31SNSQBzQreqAwx2XFUBurmP1nMn0a6qfk9eD/oZTd6qHXvXxF1m
L4iWxlsAX4edfzXAX9xN/spXyqZ1AYh8h1Tw5ZQD3yK3B5e663naqOhOKt1kwkeWKSFcAS4FKzos
kHYRaAHljSb9KBMvEswpfpKINpJDWE8NJeiezE2D2vnW1CJAC6YbcNCSl3xerKmxsZFjFK7ZwWRg
jkj+1VApoSbmHqzZgaaVDdwRs6YWSy+QlsYpBdeHygnH2uB6sPYF/OFTbVoXgPBh78bdNwW81AtW
lmxVAtix/vqGAZW+P97qMuDImho3AKzP+pmpCv3j9pvMl/q2Dc3qAbGVsdalSITj31VtZtDKXXnZ
zQBbNje/5kJpaeStLNMyQnB79enW5n287nDLSv5CNq3zR2oeUsyQmocUM/g6pOA5pZY6SRnuXrIe
Z62k72+pmuwGJis1yjg6T6khMcKQUVHdFy4UfaS9qrXVSeb0UmpNQvpba6oORx1aHpzoptI2+Gkt
V2qA4atr0xplraRnXqdaGVt8bVozlHrV/zSxrbVGqd45fmtpFMla3pfK6+7Mz8Acf6cDrBO5DWgs
sgVcjpIAfw99X4GlXB+MrkAVJ/lsEDkfrgS6ObQ86AMoPy2AoT5acwG2WlKdhhinprUH4HPfGWxr
AQzyWctGUazl+813ug3hCfbkiao0FeBl9ykeljAQaWPP0SuS6hBdKSQ0Foa5PKGxrveV+iPAtDDn
4AVgBUsOthZWt4WExiqKtXyPrIfdyU5gOsjeDnCzld1a61ne6a7RjTBUBJ4JPdoLrV5p4UmSQT3g
EYeWBwNxNvZ4aPXx0WoH0MxSvTSkTzStJuALr+Wx1gCftUwjJm0tbw8VDiXNXBwfS2mzyydae3UO
d6LtfhGZ7Q6ukV6ekeHD8G31eTxcfPJ4D1oYi+Nnn6Z6xM5xjd3N6XncoeXB6X402O6nta4yLxjr
Gzat8ag5IrK/DV2O+GktusQUPfBaa9NVPHPWby2NolgrNewtZkgNe4sZQpffvVizsEwVIG/Brjrn
3YnfLSl/RcJCsjSjRhkg88ucWgDLVlW+FDg095i5u/TU/P11ko9j9c+1V5UD9s09eTXA8hWXVwCy
5x2+JoDWurmlqgEFi7ZeY+y+t2l5EEJLWysE277Mqxl6MOFj2sIbwDwrQnjZIkYIj+MVAly4fE/l
G4nHUx8slo6LjqduSNMcAponHceqHfF46v3FUr3ZJPITlgaMh9b7wBSRs6VxhXnXtDwIoaWtFYKv
CZKm0Ui2QwAqa1fVBUnWCWqjaaJC6wBGOUFNAQYGO/auL8qJ/2g5JNpNPuR40Hpo6ct0PpgDBZuW
ByG0tLVCEOnYW5THTz7EQP9znihIVEAACt0FC8GjPlVYZB6eNjxnKAgqb9YQd9JVKphWPmGItkGS
F9kIYKb2OclNso4XLxERUNhGQT0gy5KmeUasXWVbLGkaYzdbFtAg8TYPjVbAbkua5hER6Q2ss8Q4
b/HTGgdM0o5DJ320PAihpa0VgoVEaGImPexNX9u2BXB2Vsmu5/3ReOmmO65PWEhmn7y3ErBlacP2
APOyOtYE9i2oYc7Lsr+s+IukX+oy90jnKsCuxdfcDbBw9111gEPzKndWflrLV93WCsifVdjV+OZl
0/IghJa2Vgg2/LPpnWHHUvOQYobUPKSYIbRDdt6ohuQDE0rVWgFktVcDzvhLLalW7tPwxrc0Ua8W
goxTddcAe1uqQYbI85FuqvcJYN4VFc0l6+W1Sn0A5L+kmu0EMhqqUQLyuro2w6DlwYyKV84HjvdS
9zki2Zx9TrXaC6ypq94WKByumgTIfITQ0jj9hOpwwEnatEKgreWhFQJNy4Owl0tpYLhelM6yfDD7
+wrtgqipBcAYPVYWS3zSUL1sB/QQ2QTmTo0sgHnW7KCsbmOC9p90aHmwGuBHke5Aeyf7d0At3cYU
a3YQ8HuDadn4NdDcSdq0gmFby0MrwjxTfJlRpavrYK+Lw5bOp0FUHEysH2O6qvoXtt8HeCOeuwjg
WbcHbUe3Y6/fk/dvYHryes4gAI/4HHu9pZJKJhEa1/HktWlFmMfnKBn5Dumqgyw1sPa23OUr0Bh8
waM86AQ/N5I9nT9rAi20HKUzJGkAcCvcZ1RqDx3ctDxoAXC9tcBt+Nr2MIq01YvjwfDTMs5tblK6
jyjY1vLQikBbX05Y96VDl5MiscGWUv36srQ44C81HoaFr7cvgp65IgVPW3PeVXCHsZF8SxUa7BaR
sTDSqDQRXoiJnOxs6cDOhsfzRPL6WVv3NS0vRliuL5n1qbbVyT3axoofNRWeKRDJ6RHoiB5CSyOr
OeWM7VA2rWDY1vLQCoGm5UZq2FvMkBr2FjP4l99Pr869EmDHhgqJ96SH4MTqvCsAtv2YZm7w3LXu
MlPdZe+qshUBWX+gqgIOrCxZCWBTZpWSSZ9JI7bucNWAifvhVZZ8QjByvz9t7pcrWHusiioqLdta
Gnnfn6gCsHtNeXOj6b6VpdMA2bi3agmD1uYdV/pXPbzPsP1YH/NfwwzeUzTswtKA+QOQ6WS/hWtr
yHRgkUjBjVAvz9JxmSgS6wRliqoBc64uNPMvba0lKHqSjSO4NGByKkObWBFp2dbSOFkausQseRlD
a3EhMEMkdjtUyXFo9QJ8zlm+Dhmkewlcy2ZFgulBGx7yFOASHdT0i3is1Y0Q+SYMxEwIcp64KeiK
i+NP7qMfAnxXRFqD3G2MBdhktXG1k61DwK7C6tybDPO84m3R9w45at7xRX1yaBwJ+RtfwKp8y+uV
k6Cnw2fAjFCVHE6CbsiFg5GVjrmTJwBOF5HWUXcyO17UdXK9SH9an+agt4YL3h5aDbQQ62tOuPhk
NL4G7hJLXtKYx/fHtTdkODBWq14etqRpXhA5VwbYWcQTHgZTfNLGFAI1MTU24pLq/AngTBFp2dbS
2AGUO2eJcRoTwjHAq9bnVvY5tGoR4K/vH/Zu+Kz2Y2Wg4OOND9xSxAs1jjVTGz56CeRP3NbDCAUQ
++T7bsYkUaYuvacrcOSjwkevAuZ/eevDCk59eLx33aKe8MBHpR4L2NC+dNZNvcLHkVsmX/WY4fKx
d1L5PpWKSktby8aujy9/rALIpyvuNSMjf7GgXXcFxz/MebSWQyvnw4O9fAp7qXlIMUNqHlLMENoh
R3rVfTv8o/XZl64clANk3HXLUv9RmdDwIWPJmhnNugYsWec8d+WQc6FniI2r2/sIyWJ5m3bmVnlN
q/D1Wn2O+2ll9bx2gvFgyH7s6lGFoS3nD682IEB7fu8DTczvDra15v2ss7nAr2l5rGXT2tm1WcBW
+bBXXl2ixvBPAb21yqN/1/lHuGIbLQw+zy8J2r5s4y2SEePU+BHMGY9N6zVcqpc2rQq4xDhvBkaE
Nv0HXGKcNgBm+Kz1DZhTC5uWx1o2LQjYYxC5/F5Poo6iVUz+4jva2t0D/YI7JPJ6sGPQJoe3wPTk
tWl5YtDatCAo+G30Lw3K9jsY/zuYnrw2LY+1yho8fJ68ke+QW0OPVANKwDUQtNvbsyDfPPwM1c/j
3AG4FnQQKcCh1cZdqmXI3/hKGrgx/KyeWFK36qV2Z1OiTctjLfNkzXythl0Z06FBeBC5jVhf+YbC
4/4NhMebw8dO8lznwLn3aiJks+RwfdczIRqxp+EFI61p7avq2tVn05oELYxJy3yoFi5Nv6Ns4Hr7
eLjD2ddoWyu/h+tTgk3LYy2b1ljo4tsFmhr2FjOkhr3FDKkOKWYI7ZD3lFJ74WwzpZ4GZitLXjIY
25TlwRqM0/WUegGYrJQKjzaboZSaAwxUqrkxPflPpaoeh+wqSv0plFask1I9nYev9FWqbcJdxCFY
opRaBdJDqc4xh5bGXqXU3xNay4OVSqmlDi3bWoOVqu/fWhX2MgPoroOabvXFFvXg9qiWrKCm4gt5
6kEDq9QWgPfcPP6gY62G0voSzFfv9xAUIDY5AKRpx965cVo27g/+pR5aHlxmVbJp3W78lpHespGP
rK2wB+KLzOGxpKIDNWUmVVLfO0dBn9XBTh0hKpRWFpir2ochUeynaJzQy+5ZPrXOiHhaHloGTrtp
mTbI9BUOu1DaAJ9aOlWctsRWRodeVe8B94ceXYklPtkNt9OjG68Dj2v5LGObRxVgqSXGWS2U1h4A
J/RQNpjB0oqG54BhIgcB9sZp2ZhMoCamh5YHQ4HnHVq2tSBAqjO0Q84Mu2+miMiaPr/NEpG81zp+
EL7fJza5y/AIQZ/lvV84LCJnX+nyaUQbEzq+liciWc/3NRWnsv/w8FIRkSUP/SE7nNbmAQPNjxV7
nv11hpwn8ke3f7tQRHYO/LctBi0bM7oNO+Ov5KHlQeG49qMLHFq2tQ4PfmSFr2xqHlLMkBr2FjP4
O2RJz98fB3KGdpsJsOax5w+EV9/7m19lBGTPe+CP4eFSbRSMamcu8MuEu1/LB7Ke72OupGf//qGl
Bi0bmlbeX+6eIMDm/k/tBGLj7hxdEE5L49Qfu5t70s++0vnTgOfEzqcGbDFohSDYWiG0PDj8u94B
cWK9z7CvgKpijc0mh76mNI5B0NtzFtA44cP6WVwaMH8F+vlf6pWBJQ4tDZtWH2CU81J/GRgUSsvG
dbjEOLsSNNY4ALAnTisEIdYKpuUFBIhx+jrEdFVtql1VQ8O5zocg39SfB/V0IB//NvNvAP7Dnf2Q
Q0vDpqUrjQeY6vagHRV54nbupN9l9nOAfyT6SBBirWBaQTwGejN9j6z6xt+NdCiogO0DFqpAUNSq
hiSLNF+lyuALQFXfTQs3rUZQA6BaXNoyhFYERf8nhKsAaiT6LRHW8tMKgn/fhLeHsqtau7feA/aK
5Da3nGFD0A/u8OvUHiwLf0t4hyzBNQxfj7W//WloYQyh/xOqZTu0NGxas4EMkcLO8FDMmvEsDaVl
YxSUM+KlTiZIEzPWA7oUOrSCEWKtEFoeDIYGvrdBathbzJAa9hYzpDqkmOHidsgYpTrnJSoU66vU
MGCNUip8rfFIPaVmAO8p1TYHctooNR6YrlT9I1DQQ6mR4acYqlQ/Y4qjaZ1optTHwCSlmhtinPOV
qrrfSXpo7Syj1DI/LQ2bVjBkoPXdwYN9VazwWsHWSvjuLQrA9N8MwTSADVbhq0JLmZ6iw3RQU53s
rT1Fd4TVzQCY7qP1jNHGs+6jd7uTBq0b3EbyRKZ9OdKECyFI9r+DwcNnrYv/yFqfqMBmiIe1Cl8E
+Nb4ey2sNZIrYSPAvrC6u+OncdEy4z15Yj8tdycNWp4Z/7fu5FqisA3cHw4sfBNprYt+hySUl1kL
kGX5q4SPqMcBDXSTM0VmaK71gLctaRqOhdXNAtf+PU1rIlBJRCrics1shes7kYfWS7j8ZGxaGjMi
TbgZXB5LGiOA1lLUjXLnhZ3dms9MXGrJrR0zROTMoCpDwtfsC8fVe+SwiOzpfv2nIiKTm3bfKyKH
e9d/OyYi827usiX8DBkdbzXH/ZpWbEKjh7NEJOuhRuanhOw+tUcb3lceWnnDqw8wPKdsWjY0rRAs
b9s+IHhFwajafbPDrJXMPCTn+9WrMzJPla523U0tm9VPXD6FC0DCDtn5yZ/cI4H7n/75BQb1SSEC
CUQw59/zn195doZv/ugVubF8ZC3WjNl9g99lNTZxQtk6/sKH315W/zJg3hsnrldw6r35V18OLH9j
//XhQ46db2Y0NhxlssZ9e63BKfudJXXSQuvmTfj88hrA5rGbmwZ4wU7578JGRlrTsqFpnf3H9CrV
gIyx25sasTaSo7VkzOEbFOSMn1Pdv0wY+bAPtfsfI/1kv8aSl/TgCQLEVuK+Y+8Dg7X45E5Lx6VH
6Bl24BLjPARw3HkNgCuQuwftgHRrg2ct/9FXwJRM1rRs2LRuBNZY22ENaZrkaH2OJeRTA9joPX1E
hxy+N+om+DKiQ+xgr95z4fJN1ZgJMNHtqjo8KQ/a7+LJD8EMfvsVRHnyAnSJDI1rZJd0J00P2j6O
v3GRaNU02vit9/ThD4XFVeYQgS7/Fu5sEyFZ6w/aUwGgYvzIpQCXQ9Wok1t+944IQVq8IUAHh6oU
2UAViJAQNqLneQibtCr7PkwkR6uaUcNPIuwy+huJUOtgWN1MAlUexxHk3VPQHBrkWVOLSSKxLlDu
pDWGHxl2AjlZFu51hq559aGFM3SNtYVq4VKdLwG7RY4SoI5kTS2M2YGmZcOmNRDIsmY8xqQlOVpr
gbfFEuP0CQeEjLLkxf9K2CGQeU3IgRMbrgoaHmfubhJw88iG2A0lgAObGtQG+PHMjaWBYxtr1iMU
eesvNT8qxdaXNN+8suncjRFhrbYfvKEikJuR1ijg6N6tjWsYSZuWhk1r29EbLgXOrK9sfsJKjtbh
jXXqAGw5caMvtFxIh7xg9keVlnVuaN6wUu7uHzZs/WGn6Xi4N/qzXApFR3CHvDHIKXBNr9tviyu4
5K5b+ck6Z15S8lhFUri4CHrIGuHeq7+4Pc91rGD/uObOFKODeyfi5zDQWIVYCD1yfK3HXrZ2U2+5
knq7JQwn77FUIGZB3zyRc32snSJfQ6eTIrHfufw2vXgXhhrMNK2cB2Hhv4ZWCF6DMVI0BHWIo0ei
OizO8x/f9oSj2+QeXIL1ujKSL/qqzwLYbA3Dm0sYntBXC8BrIn82kgN0rNVQs/0Irg/hmtZgo42L
TCsYS6HIkViDhr2P23+UeeTd9gHLJA3++tf46O8Z3+pyujvpl0ldDbAZ9gPrQu/cWcbfX8FX7kMr
wLcx3cGP8dO4aJlU/gW0/FgHsIGiwd9HS+xDpZ8OG9jGPo+PpW81H1rgkpcBAuIEpQNkWtI0PUOv
lOFAOd3GB45MbBngVZF5AAfC6u4Cl6empjVGt/EvoBWMNRAlExsIf2sF9nqJejT0F0vsg/jb3JTt
XVNPvW100OamvBqgmD+5fPWlInKkG48cDz1D3ks03ykiGY0YHROJjaJRhojsbM6QPBGZcEntFaF1
ZUn1S82QuJpWwXCu3/KvoRWCGWmVi6qo5B9lzbfVVDuMr6P/OrpiQcaPRypee0P7n1fXw+rcofZu
1YZbko90k0Ji+K59ezZW3Z6unpnbs6Y1yypRpfOkbJ27+w67hfP2xEghAL7l913/af2vnn7ceuEf
++//+PaUNRuUnO1fHW1sTUrSqszW85F8JxZfwZcrrroM2Pn50XrGfZM1dV+9EiBL55Qz13GWTSlh
TizXfJ53DZA357sa5YHNn5+sa7Sxd8rB+kby8LTd9UoC/5xZujpwasbmOpcAKz+L1QbOzlp3dUB4
dU1LFi6+3NDGtGllT99et5RDK2fmhtpl/LQ80LRk8fyKlRPS8sC2VvQdMlzn19W7K48Odu9MLfWA
3lZ+oped5XzwvBnItBZrDHnJXVhiK3/AtUr0Fq65xHRghEhBXSDL2nRtSNP8iEsDZj9Qv8DScZmh
48zkWPIy40TOVSBglShO65e41tQ0rSNAWl6clh3QxUPLA5vWU8DyRLS80NZyw9shMXuh8w/W3tic
P3t3Cpd8Qodd/Mx+r692WgP+4HNVNT1oDU9ez/VQwUp+DzDS59j7hDs5AmBt3GV2MsDceJPp4PLk
1bjf4NHdzaOR9qBdFm/jS4DPfLQ8MKclbRPR8tnespYb3nnIMf0cqnK79dr45397PW8KP5tqnaFt
a53zpfsWAs/cxVzmC//6q4+UTNyGXapkvKKZRO/+Kxl2hiAe/jbspIeWB6XC2/A3GQR/k54Osqd1
91p7bI70DGjkNq3na2/Kc3xz2hOPT2eIT+7D0sQcjmuQPAHXpGUe8KZIYTPiYfMMPZkdwENO8jDQ
otCaWsy3vsWVP2fJS34gkl+LIE1Mm1Z/XKo3mtZxoHZBnNa5ssAZHy0PbFqDgTWJaHmhreW5bTzp
0drIv7GSs2sEdMhlr1sHF/o79esZx0RE9n3mmiQcm25pSH030bXtf937rgHajx+sERGJLfnilIhI
5ieuPX+Hpro0eU5+sSQmIrLmgx9FRM7NXVAgIpLx/joRkcLFc/yLVQ6t5Z+57KBp5cxZXGjQKlgw
71wALQ9sWis/yUxMywttrcgOeUTbWL+DfhN4w3W0Dp7xd0gKFwrvO8TeOdnc+m99oBjhSuu/BFtP
UjgfeDskU/+vP4NtDqx0gmjkD1ZXrvNnb6un+p0B3nPJudg4/qBqvhtYVEqNBc4OVFdtAlZWUMNi
EBuqKq4ySo9RpRYBu5upnieAiUpNBY50Um2zgNnWnvQzfVX97UB6OTVSQmmFYIpSkwxa0dhUTT1t
7DHw0LIRTMsDzx1jz730Wk/IEEEXDmlDXgvKtEaQA/XXFr8P2S+B+lpgeqY1O7AHlOO0fKFTeAbA
Pkt8srfItwAZIvcArUS2ASy2Zgdpuo2JobSCsR5gZZxWAoAVfkDDQ0sjhJanJU/a3uWlX2AhwR4S
dEhIsFdd9o8A08KOLgB4WuQKo0Pa+xx7nwJYFK/0OsD78eRUgP9wx6B6OEEMWi/+DjA6kReuSb6y
O2nQ0gih5Yb3kWUvbei7NGgTgBWQKgoPhR96XGtA+iMzdbPOfh1AO3jMONTVF/upnSZXBbgPWgO0
sJpuqhtvA31xnsn3RNLy4yaAVnFaScBg7KGlEULLA08H2YrleufLrwP3bd2W4A451x8CFscz0rj/
hIiMgk/9Rw+35+qtIjIDXo2JnOlNiTUisgSeLxDJH+RyZI0Nt4LNbqnFXUdEZJw10N/fiqaZIjLZ
ki460Y1KG0RkHgwpDKUVggnWx0+bVjTWKB4xNGk8tGwE0/Lca57077WNf28lPwna81ZW+/VvCOuQ
FM4f3jvA1rPdkQtA258FdEhD/fyYRQoXHd4OsYV911rOWjUf87/WSz9siQvn2v5cjzrH1iw+BXB4
ruWq9cPcIwCnFllyMpu+cMm8bZ22w0xmTg8cZK9dcBwge4F1ug1zXG5wm6dnJv9jbVoaNq1gxJYv
S0K20UMrd8l3Jq2CZcujgr5ra7nhuWPie65GW+njz3iXv1RXvWS82A7h6IyYugIHRbZiia08B2yz
dFzuE2vQYSyHfIJrC81XBOrN9QH2WDou/cTysjQWXN4lKNRRCGxaGjatYOTVhIpnEzXpoXUMaBuL
08qtALXCFSW0tdzwPf/v11Zutd9K73zAPRdRd+p9LecG21lOowDD3B60vd0etMYGG8/1EBLUFOBZ
twdtR/dRfyTWEBTdg3Z6oiY9tEZD3MG4uvY3XhxaWVvLDd8oylY5XTfD+r/uyH7mF5HSv3hdS55v
mayz6rs3qufERR8BOAM5RvIkYQg/wpl4YCfAF2wqoqIbp93JnMjC5wDOkgAeWrnxmnBSV49uw0/C
20O59oEW9mDvyDu32h8ay94wPFPvKjnd1y5oDGEbA9sssZX7xVK9XGXNUJuK9QQztq+9jusZNZnA
OMdtgAxr4nyHWKqXxvB3KIFD6GDYtDRsWsE4BZCdqEkPrT1Atfw4rWyIEBuzreWGf9fJ0D9Z/6tf
v64/CRZu/3LeyhNQ5mcd7rvR/rIz8TfH7avEWWTMm3bo/trApjn17ysJhTN23dsY2D2zavfSILPX
dzSjEsxffmc7I7lsccvO/g0sBdN/6toA2D6r1gOlIPbF5s5GRAGZu7rD7Yku4zg0LRuaVghOTCvs
fkXCJj209k+v9GBZh9axaSUfDN/9bFvLBX+HHLafQOVHDgzf4LPwSXvL4msvJm2QFBLD7/R5aeHX
1h/5q+s2DuuRFb/dZP85LdFCSgpFgv/R5rwkq30Y7IYUW+DEMgnag174RoWfZ4rIrp9XGBMg1Dur
zo0rReR4HwaeFpGvGzdcaBxde1PNKSJS8FrZu/aJyNbbr3gvJhJ794rbA1QUj3RncK6ILGzQ+GsR
Of0UfY1Pt3kvl+wc6uYVx4FOJYfmObRsaFq5v6PH0YRthNAKRiStoHGfs2mh4uA9AcfPfOS4Nt1U
GFDgXUCJNa7zb/74FmCvNQzvZ80OjKnFIYAllvhkVd3GZGvSEsD1NmCQXivfZk1ajEBEL5OMGGcj
YKhDS8Om9SzQpqgdommFIJJW4EB8QNzepe+Y7XWAzl3fx3AB/ymovumqerPv6J8AvojPQz4E06vh
K4Dful1Vu0Q69qJj0E5M5EEbZgLgEoeWhk2LpNoIphWCSFqBq7lj4hsK877u9W+fm2sVOUte7vKh
88Vwcc2g+neE/G2hGUADqGj9dx1A0/jROgA3QXujxm1wW/hDt7Wu3sgKQ1XJOdKRZNHRoaVh02qZ
dBt+WuEni0BgN7mi+qZ1GLxQLy1v+MtDV5uHQqT1T3WwFsdnwl3+YXhskLUwk6GotF1EhrtddsfB
gEKR7FZWoKbJcP9ZkdxugROOVVB7r4i8BK+KyLY0SmwwfkZj9+b8YHwNTQ85tGxoWntqmZ7nScKm
FYxIWiFOn7vrJHMRjB50vpdPCmEIE5/5qU5hwrrjf/2/zf7/QYQpOdQ61iFR1UWp/vgXIFRao+LC
NyMr3vRTwh5juFLKkJecYMlLnmus1H0C85RSyyDWXqnW4V8eBiuljsBhFagnqVHQUqkOMUhXSs0H
6aZUk3AxTk3rREWlnvTT0rBprVFKTXPq7lRKGYYJoTVFKfW9Q8uDTUqpD4ABSqX5d1RFvJp2RETb
nCRJAFyxRQFu1R60a+IhT5dClHY0wGAd1DS00CyAr+NBTVeDGYk1hNarukkPLQ2bVh33iX/hTobQ
Aqjn0PKglXFiX9zaKBHMesvTQ5TPR5zsTZLwhILK1KGYjlvJHDgGEB0Xer/lGxuOowDH4kvdxwEO
Rdb4SQeuCqaFQyvTXc8THSuC1i6Hlgfmvrss39EEF3nGE74a9T89I8mhFS4PnV7AJEuahpOWBsxI
SwMmwBXGRj1ghaUB0yC0UBbAUcs/Y4he/Al3/te01mJpYnpoadi0xuGSl5mBSxMzhNZA4G2HlgcT
sVRvKhIgxpOE5uKaLz9xhIUf7X571YQ1bOS+veVRIxJvwTvfPdQF2P7upU9VhdiEBd16Kdg/rvDJ
2qFtnHkrs19LYNUHdZ+6NLTU7ndKPVkD5ONZ9/QtAYfG5fRvEFrYpvXDP6oPrOijZUPTkmnT2z5h
rNkv/rjZk8aafTCtwvHp3R9QcVpezPms1b+VghPjsn7lC06cEuMvZkhpvxczpDqkmCHVIcUMqQ4p
Zkh1SDFDqkOKGVIdUsyQ6pBihlSHFDOkOqSYIdUhxQypDilmSHVIMUOqQ4oZUh1SzPD/AYVl+fu6
mq4cAAAAAElFTkSuQmCC'/>`
        })
    }
})();

// 解析url参数
function getQueryVariable(variable) {
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
};

// 正则匹配
function getStr(str, start, end) {
    let res = str.match(new RegExp(`${start}(.*?)${end}`))
    return res ? res[1] : null
}

// 获取答案
function getAnswer(columnId) {
    var html = $("html").html(),
        taskId = getStr(html,'&taskId=','`,')

    $.ajax({
        url: _self.config.practice.host + _self.config.practice.practice + "?columnId="+ columnId + "&taskId=" + taskId,
        headers: _self.config.apiConfig.header,
        async: false,
        success: function (res) {
            const { data, status } = res;
            if (status === "0") {
                var question_data = res.data
                var questionBankList = data.questionBankList
                answer_list = questionBankList;
                upload(question_data)
            } else if (status === "1") {
                //无效的columnId（下个接口是chapterId）
                alert("请先学习当前模块");
                window.history.go(-1);
            } else if (status === "-2") {
                alert("请重新登陆");
            } else {

            }
        },
        error: function (err) {
        }
    });
}

// 答题操作
function doQuestion(t) {
    var cur_topic = $('#currentTopic').text(),
        tol_topic = $('#totalTopic').text(),
        answer = answer_list[cur_topic - 1].answer;
    $('#exam_answer > div:nth-child(' + num[answer] + ')').click();
    if (cur_topic == tol_topic) {
        // 清除Interval的定时器
        clearInterval(t);
        setTimeout(function(){Swal.fire('宪法小助手提示','答题完成','info')},time / 2);
    } else{
        setTimeout(function(){$('#next_question').click()},time / 2);
    };
}

// 获取考试题目
function getExam(){
    var html = $("html").html(),
        taskId = getStr(html,'taskId=','`,');
    $.ajax({
        url: _self.config.wexam.host + _self.config.wexam.getPaper + "?taskId=" + taskId,
        headers: _self.config.apiConfig.header,
        async: false,
        success: function (res) {
            const { data, status, message } = res;
            if (status === "0") {
                var question_data = res.data;
                var paper = question_data.paper;
                var paperInfo = paper.paperInfo;
                exam_list = paperInfo;
            } else {
                alert('获取考试题目失败！')
            }
        },
        error: function (err) {
        }
    });
}
// 考试答题操作
function doExam(t){
    var cur_topic = $('#currentTopic').text(),
        tol_topic = $('#totalTopic').text(),
        questionInfo = exam_list[cur_topic - 1];
    $.ajax({
        url: 'https://cx.gocos.cn/xf-api/v1/cx?v=3',
        type: 'POST',
        data: {'data':encodeURIComponent(JSON.stringify({
            'question': questionInfo.content,
            'answerops':questionInfo.answerOptions,
            'topicId': questionInfo.id
        }))},
        async: false,
        success: function (res) {
            if (res.code == 1) {
                var data = res.data;
                var answer = data[0].answer
                var answerText = data[0].answerText
                $('#ne21ans')[0] ? $('#ne21ans').html('<p style="color: red;">参考答案：'+ answerText + '</p>') : $('#exam_question').append('<div id="ne21ans"><p style="color: red;">参考答案：'+ answerText + '</p></div>')
                $('#exam_answer > div:nth-child(' + num[answer] + ')').click();
            } else {
                var msg = res.msg;
                Swal.fire('宪法小助手提示',msg,'info')
            }
        },
        error: function (err) {
        }
    });
    if (cur_topic == tol_topic) {
         // 清除Interval的定时器
         clearInterval(t);
         setTimeout(function(){Swal.fire('宪法小助手提示','答题完成,请自己点击交卷！','info')},time / 2);
    } else{
         setTimeout(function(){$('#next_question').click()},time / 2);
    };

}

function upload(question_data) {
    $.ajax({
        url: 'https://cx.gocos.cn/xf-api/v1/upload',
        type: 'POST',
        data: {'data':encodeURIComponent(JSON.stringify(question_data))},
        async: true,
        success: function (res) {
            Swal.fire({
                position: 'top-end',
                title: '本章节测验题目数据已收集完毕！',
                showConfirmButton: false,
                timer: 1500
            })
        },
        error: function (err) {
            Swal.fire({
                position: 'top-end',
                title: '发生未知错误，请联系作者！',
                showConfirmButton: false,
                timer: 1500
            })
        }
    });
}