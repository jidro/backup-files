// ==UserScript==
// @name         【万能视频自动刷课时播放脚本】各类专业技术人员，新疆继续教育，教师，会计，华医网，好医生，医学继续教育公需课专业课·····
// @version      1.1
// @description  【弘成教育学起plus】【国开在线】【各类继续教育】【各类教师培训】【各类会计】【合作微study-088】。
// @author       万能脚本
// @match        *://*/*/*
// @license      MIT
// @namespace https://greasyfork.org/users/1030542
// ==/UserScript==
 
const page = (pathname) => {
  return new Promise(resolve => {
    const timer = setInterval(() => {
      if (pathname[0] === '/') {
        if (location.href.includes(pathname)) {
          clearInterval(timer)
          resolve()
        }
      } else {
        if (location.href.includes(pathname)) {
          clearInterval(timer)
          resolve()
        }
      }
    }, 300)
  })
}
 
document.querySelector('video').defaultPlaybackRate = 3.0;//设置默认三倍速播放
 
document.querySelector('video').play();
 
const getElement = (selector) => {
  return new Promise(resolve => {
    const timer = setInterval(() => {
      const element = typeof selector === 'string' ? document.querySelector(selector) : selector
 
      if (element) {
        clearInterval(timer)
        resolve(element)
      }
    }, 60)
  })
}
 
page('/personback/#/learning').then(() => {
  getElement('video').then(video => {
    video.muted = true
  
    const playList = Array.from(document.querySelectorAll('.el-steps .el-step .title-step'))
    let currentIndex = 0
  
    const nextVideo = () => {
      let currentNow = Date.now()
  
      const timer = setInterval(async () => {
        if (isNaN(video.duration)) {
          video = await getElement('video')
          video.muted = true
        }
  
        if (Date.now() - currentNow < 15000) {
          if (video.paused) {
            video.play()
          }
  
          return
        }
  
        if (video.currentTime >= (video.duration - 1) && video.paused) {
          currentIndex += 1
  
          if (currentIndex >= playList.length) {
            currentIndex = 0
          }
    
          playList[currentIndex].click()
    
          clearInterval(timer)
  
          setTimeout(() => {
            nextVideo()
          }, 1000)
        }
      }, 1000)
    }
 
    setInterval(() => {
      const button = document.querySelector('.el-dialog__wrapper .el-button span')
 
      if (button) {
        button.click()
      }
    }, 1000)
  
    nextVideo()
  })
})