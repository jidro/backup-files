// Global variables only exist for the life of the page, so they get reset
// each time the page is unloaded.
var counter = 1;
var URL_ZHWAN_LEGAO = "https://zhwan.liebao.cn?frm=lb-legao&referer=llqzy";

var lastTabId = -1;
function sendMessage() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    lastTabId = tabs[0].id;
    chrome.tabs.sendMessage(lastTabId, "Background page started.");
  });
}

// sendMessage();
// // chrome.browserAction.setBadgeText({text: "ON"});
// console.log("onLoaded => ");

// // chrome.runtime.onInstalled.addListener(function() {
// //   console.log("onInstalled =>");

// //   // localStorage is persisted, so it's a good place to keep state that you
// //   // need to persist across page reloads.
// //   localStorage.counter = 1;
// // });

// // chrome.bookmarks.onRemoved.addListener(function(id, info) {
// //   console.log("chrome.bookmarks.onRemoved => id:" + id);
// // });

chrome.browserAction.onClicked.addListener(function() {
  console.log("chrome.browserAction.onClicked => ");
  // The event page will unload after handling this event (assuming nothing
  // else is keeping it awake). The content script will become the main way to
  // interact with us.
  chrome.tabs.create({url: URL_ZHWAN_LEGAO}, function(tab) {
    // chrome.tabs.executeScript(tab.id, {file: "zhwan_content.js"}, function() {
    //   // Note: we also sent a message above, upon loading the event page,
    //   // but the content script will not be loaded at that point, so we send
    //   // another here.
    //   sendMessage();
    // });
  });
});

chrome.commands.onCommand.addListener(function(command) {
  chrome.tabs.create({url: URL_ZHWAN_LEGAO});
});

// chrome.runtime.onMessage.addListener(function(msg, _, sendResponse) {
//   // if (msg.setAlarm) {
//   //   // For testing only.  delayInMinutes will be rounded up to at least 1 in a
//   //   // packed or released extension.
//   //   chrome.alarms.create({delayInMinutes: 0.1});
//   // } else if (msg.delayedResponse) {
//   //   // Note: setTimeout itself does NOT keep the page awake. We return true
//   //   // from the onMessage event handler, which keeps the message channel open -
//   //   // in turn keeping the event page awake - until we call sendResponse.
//   //   setTimeout(function() {
//   //     sendResponse("Got your message.");
//   //   }, 5000);
//   //   return true;
//   // } else if (msg.getCounters) {
//   //   sendResponse({counter: counter++,
//   //                 persistentCounter: localStorage.counter++});
//   // }
//   // If we don't return anything, the message channel will close, regardless
//   // of whether we called sendResponse.
// });

// // chrome.alarms.onAlarm.addListener(function() {
// //   alert("Time's up!");
// // });

chrome.runtime.onSuspend.addListener(function() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    // After the unload event listener runs, the page will unload, so any
    // asynchronous callbacks will not fire.
    // alert("This does not show up.");
  });
  console.log("Unloading =>");
  // chrome.browserAction.setBadgeText({text: ""});
  chrome.tabs.sendMessage(lastTabId, "Background page unloaded.");
});
