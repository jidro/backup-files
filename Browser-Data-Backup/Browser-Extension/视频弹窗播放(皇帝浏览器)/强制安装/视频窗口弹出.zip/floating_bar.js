var $ = (function() {
  var pageElement = function(element) {
      this.element = element;
  };
  pageElement.prototype = {
    element: {},
    setStyle : function(param) {
      if (typeof param === 'object') {
        for (var name in param){
          this.element.style[name] = param[name];
        }
      }
      if (typeof param === 'string') {
        this.element.style.cssText = param;
      }
    },

    addEvent: function(type, listener, useCapture) {
      this.element.addEventListener(type, listener, useCapture);
    },

    removeElement: function() {
      this.element.parentNode.removeChild(this.element)
    }
  };

  var getElement = function(element) {
    var newElement = element;
    if (typeof element === 'string') {
      newElement = document.getElementById(element);
    }
    return newElement;
  };

  return function(element){
    var newElement = getElement(element);
    return !!newElement ? (new pageElement(newElement)) : false;
  };
})();

var floatingBarClass;
var floatingBarMenus;
var isWindowsPlatform = navigator.userAgent.toLowerCase().indexOf('windows') > -1;
chrome.extension.onRequest.addListener(function(request, sender, response) {
  if (request.msg == 'restoreVideoAlone') {
    response(floatingBar.restoreVideoWindow());
  } else if (request.msg == 'status') {
    initFloatingBarMenu();
  } else if (request.msg == 'restoreTabTitle') {
    document.title = request.orgTitle;
  }
});

chrome.extension.sendRequest({msg: 'getStatus'}, function(response) {
  if (response.msg == 'status') {
    initFloatingBarMenu();
    init();
  }
});

function initFloatingBarMenu() {
  floatingBarMenus = {
      menuID: '004',
      menuName: chrome.i18n.getMessage('video_standalone'),
      imageURL: 'images/floating_bar_video.png',
      isWindowsOnly: true
    };

  floatingBarClass = {
    OBJECT : [{menu: floatingBarMenus, operate: 'popupVideo'}],
    EMBED : [{menu: floatingBarMenus, operate: 'popupVideo'}],
    VIDEO : [{menu: floatingBarMenus, operate: 'popupVideo'}]
  }
}

var floatingBar = {
  listeningElements: ['OBJECT', 'EMBED', 'VIDEO'],
  nodeStyles: [],
  curVideoSize: {videoElement: null, height: null, width: null},
  videoAloneFlag: false,
  minWidth: 50,
  minHeight: 50,

  addEvent: function(listener, menuBar) {
    var timer = null;
    var hidden = function() {
     if (timer != null) {
       return;
     }
     timer = window.setTimeout(function() {
        if ($(menuBar.id)) {
          document.body.removeChild($(menuBar.id).element);
        }
      }, 1000);
    };
    var show = function() {
      window.clearTimeout(timer);
      timer = null;
    }
    listener.addEventListener('mouseout', hidden , false)
    menuBar.addEventListener('mouseover', show, false);
    menuBar.addEventListener('mouseout', hidden, false);

  },

  onMouseMove: function(event) {
    var curElement = event.target;
    var curElementName = curElement.tagName;
    if ((curElementName == 'OBJECT' || curElementName == 'EMBED') &&
        curElement.type == 'application/pdf')
      return;
    var checkedElements = floatingBar.checkCurrentElement(floatingBarClass, curElementName);
    if (checkedElements && !$('media_floatingBar')) {
      var floatingMenu = document.createElement('div');
      var curElementData = floatingBar.getCurElementData(curElement);
      floatingMenu.id = 'media_floatingBar';
      var floatMenuHeight = 25;
      var floatMenuTop = curElementData.top - floatMenuHeight;
      if (floatMenuTop < 0) floatMenuTop = curElementData.bottom;

      var styleProperties = {
        position: 'absolute',
        left: curElementData.left + 'px',
        top: floatMenuTop + 'px'
      };

      $(floatingMenu).setStyle(styleProperties);

      for (var i = 0; i < checkedElements.length; i++) {
        var isWindowsMenu = !isWindowsPlatform && checkedElements[i].menu.isWindowsOnly;
        if (!isWindowsMenu && curElementData.minSizeChecked) {
            var imgElement = floatingBar.createImageMenu(
                checkedElements[i].menu.menuID,
                checkedElements[i].menu.menuName,
                checkedElements[i].menu.imageURL);
            (function(operates) {
              imgElement.onclick = function() {
                floatingBar.operate(operates, curElement,
                    curElementData, floatingMenu);
              }
            })(checkedElements[i].operate);
            floatingMenu.appendChild(imgElement);
        }
      }
      if (!$(floatingMenu.id)) {
        document.body.appendChild(floatingMenu);
        floatingBar.addEvent(curElement, floatingMenu);
      }
    }
  },

  checkCurrentElement: function(listeningElements, curElement) {
    return listeningElements[curElement];
  },

  operate: function(todo, curElement, position, floatingMenu) {
    switch(todo) {
      case 'showOriginalPicture':
        floatingBar.showOriginalPicture(curElement, position, floatingMenu);
        break;
      case 'popupVideo': floatingBar.popupVideoWindow(curElement, position);
        break;
    }
  },

  getCurElementData: function(curElement) {
    var curElementData = {
      top: 0,
      left: 0,
      width: 0,
      height: 0,
      minSizeChecked: true
    };
    var node = curElement;
    curElementData.width = node.clientWidth;
    curElementData.height = node.clientHeight;
    if (curElementData.width < floatingBar.minWidth ||
        curElementData.height < floatingBar.minHeight) {
      curElementData.minSizeChecked = false;
    }
    
    var range = document.createRange();
    range.setStartBefore(curElement);
    range.setEndAfter(curElement);
    var clientRects = range.getClientRects();
    if (clientRects && clientRects.length == 1) {
      curElementData.top = clientRects[0].top + document.body.scrollTop;
      curElementData.left = clientRects[0].left + document.body.scrollLeft;
      curElementData.bottom = clientRects[0].bottom + document.body.scrollTop;
    }
    return curElementData;
  },

  createImageMenu: function(menuId, menuName, imageURL) {
    var divElement = document.createElement('a');
    divElement.id = menuId;
    divElement.title = menuName;
    var background = 'url(' + chrome.extension.getURL(imageURL) +')';
    $(divElement).setStyle('background-image:' + background);
    return divElement;
  },
  
  setOtherNodesInvisible: function(element, styles) {
    if (element && element.parentNode != document.documentElement) {
      var nodes = element.parentNode.children;
      for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].style && nodes[i].style.display != 'none') {
          styles.push({node: nodes[i], display: nodes[i].style.display});
          if (nodes[i] != element) {
            nodes[i].style.display = 'none';
          }
        }
      }
      element = element.parentNode;
      floatingBar.setOtherNodesInvisible(element, styles);
    }
  },

  getComputedStyle: function(element, style) {
    return window.getComputedStyle(element, style)
  },

  popupVideoWindow: function(curElement, position) {
    var curElement = curElement;
    var styles = [];
    var tabTitle;
    styles.push({node: document.body, cssTest: document.body.style.cssText});
    styles.push({node: curElement.parentNode,
                 cssTest: curElement.parentNode.style.cssText});
    var styleProperties = {position: 'fixed',
                           top: 0,
                           left: 0,
                           margin: 0,
                           padding: 0,
                           height: '100%',
                           width: '100%',
                           zIndex: 9999,
                           backgroundColor: '#000000'};
    var objectElement = curElement;
    if (curElement.tagName == 'EMBED' && curElement.parentNode &&
        curElement.parentNode.tagName == 'OBJECT')
      objectElement = curElement.parentNode;                           
    $(objectElement.parentNode).setStyle(styleProperties);
    floatingBar.curVideoSize = {videoElement: curElement,
                                height: curElement.height,
                                width: curElement.width};
    floatingBar.setOtherNodesInvisible(objectElement, styles);

    floatingBar.nodeStyles = styles;
    document.body.height = position.width;
    document.body.width = position.height;
    document.body.style.overflowX = 'hidden';
    document.body.style.overflowY = 'hidden';
    tabTitle = document.title;
    document.title += Math.random() * 1000000;
    floatingBar.videoAloneFlag = true;
    window.onresize = function() {
      if (floatingBar.videoAloneFlag) {
        styleProperties = {width: document.documentElement.clientWidth + 'px',
                           height: document.documentElement.clientHeight + 'px'};
        $(curElement).setStyle(styleProperties);
      }
    }
    chrome.extension.sendRequest({msg: 'popupVideoWindow',
                 width:position.width,
                 height: position.height,
                 orgTitle: tabTitle,
                 uniqueTitle: document.title});
  },

  restoreVideoWindow: function() {
    var nodeStyles = floatingBar.nodeStyles;
    var curVideo = floatingBar.curVideoSize.videoElement;
    if (curVideo) {
      curVideo.height = floatingBar.curVideoSize.height;
      curVideo.width = floatingBar.curVideoSize.width;
    }

    for (var i = 0; i < nodeStyles.length; i++) {
      nodeStyles[i].node.style.cssText = nodeStyles[i].cssText;
      nodeStyles[i].node.style.display = nodeStyles[i].display;
    }
    floatingBar.videoAloneFlag = false;
    return {msg: 'restoreVideoWindow'};
  }
};

function init() {
  document.addEventListener('mousemove', floatingBar.onMouseMove, false);
}
