   var plugin = {
    CUSTOM_CAPTION_HEIGHT: 40,
    convenience: document.getElementById('plugin_convenience'),
    videoAlone: document.getElementById('plugin_videoAlone'),
    showVideoAlone: function(title, orgTitle, parentWindowId, curWindowId, tabId) {
      this.videoAlone.ShowVideoAlone(title, orgTitle, parentWindowId, curWindowId, tabId);
    },
    getWindowMetric: function() {
      var json_str = this.videoAlone.GetWindowMetric();
      return JSON.parse(json_str);
    }
  }
  chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
    switch(request.msg) {
      case 'popupVideoWindow':
        videoAlone.popupWindow(request, sender, request.width, request.height);
        break;
      case 'getStatus':
        sendResponse({msg: 'status', videoBar: true});
        break;
    }
  });

  chrome.tabs.onSelectionChanged.addListener(function(tabId) {
    chrome.tabs.sendRequest(tabId, { msg: 'status', videoBar: true });
  });
  
  var videoAlone = {
    popupWindow: function(request, sender, width, height) {
      var parentWindowId = sender.tab.windowId;
      var obj = plugin.getWindowMetric();
      chrome.windows.create({
        width: width + 2 * obj.borderWidth,
        height: height + obj.captionHeight + 2 * obj.borderHeight,
        tabId: sender.tab.id,
        incognito: sender.tab.incognito,
        type: 'popup'
      }, function(window) {
        chrome.tabs.getAllInWindow(window.id, function(tabs) {
          plugin.showVideoAlone(sender.tab.title, request.orgTitle, parentWindowId, window.id, sender.tab.id);
          chrome.tabs.sendRequest(sender.tab.id, {msg: 'restoreTabTitle', orgTitle: request.orgTitle});
        });
      });
    },

    restore: function(parentWindowId, curWindowId, tabId) {
      var newWindow = null;
      var restoreAllTabs = function(tabs , count) {
        if (tabs[count].id == tabId && ++count >= tabs.length) return;
        chrome.windows.get(parentWindowId, function(window) {
          if (window) {
            chrome.tabs.getAllInWindow(window.id, function(parentTabs){
              chrome.tabs.move(tabs[count].id, {windowId: window.id,
                  index: parentTabs ? parentTabs.length:0 }, function() {
                count++;
                if (tabs.length > count) {
                  restoreAllTabs(tabs, count);
                }
              });
            });
          } else {
            chrome.tabs.get(tabId, function(tab) {
              chrome.windows.create({
                incognito: tab.incognito,
                type: 'normal'
              }, function(window) {
                newWindow = window;
                restoreNoParentWindow(tabs, window.id, count);
              });
            });
          }
        });
      }

      var restoreNoParentWindow = function(tabs, parentWindowId, count) {
        chrome.tabs.move(tabs[count].id, {windowId: parentWindowId, index:0}, function(){
          count++;
          if (tabs.length > count) {
            restoreNoParentWindow(tabs, parentWindowId, count);
          }
        });
      }

      chrome.tabs.getAllInWindow(curWindowId, function(tabs) {
        restoreAllTabs(tabs, 0);
        chrome.tabs.sendRequest(tabId, {msg: 'restoreVideoAlone'}, function(response) {
          if (response && response.msg == 'restoreVideoWindow') {
            chrome.windows.get(parentWindowId, function(window){
              if (window) {
                chrome.tabs.getAllInWindow(window.id, function(curTabs){
                  chrome.tabs.move(tabId, {windowId: window.id,
                      index: curTabs ? curTabs.length:0 }, function() {
                    chrome.tabs.update(tabId, {selected:true});
                  });
                });
              } else {
                // if parent window closed, create a new window
                if (newWindow) {
                  chrome.tabs.move(tabId,
                    {windowId: newWindow.id, index:1}, function(){
                    chrome.tabs.update(tabId, {selected:true});
                    chrome.tabs.getAllInWindow(newWindow.id, function(tabs) {
                      chrome.tabs.remove(tabs[0].id);
                    });
                  });
                } else {
                  chrome.tabs.get(tabId, function(tab) {
                    chrome.windows.create({
                      incognito: tab.incognito,
                      type: 'normal'
                    }, function(window) {
                      chrome.tabs.move(tabId,
                        {windowId: window.id, index:1}, function(){
                        chrome.tabs.update(tabId, {selected:true});
                        chrome.tabs.getAllInWindow(window.id, function(tabs) {
                          chrome.tabs.remove(tabs[0].id);
                        });
                      });
                    });
                  });
                }
              }
            });
          }
        });
      });
    }
  }

  function getNPMessage(messageId) {
    var npMessage = {
      1001: 'np_message_1001',
      1002: 'np_message_1002',
      1003: 'np_message_1003',
      1004: 'np_message_1004',
      1005: 'np_message_1005',
      1006: 'np_message_1006'
    };
    var message = '';
    if (npMessage[messageId]) {
      message = chrome.i18n.getMessage(npMessage[messageId]);
    }
    return message;
  }
